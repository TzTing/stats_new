CREATE proc GDanaly2 (@years int,@distid varchar(50),@cc int)  as
begin 
delete from T_analy

insert into T_analy(years,distid,distname,c14) select years,distid,distname,c12 from rep901 where years=@years  and len(distid)/3<=@cc  and (lx is null or lx='汇总数') and c12<>0
update T_analy  set c1=rep902.c1,c4=rep902.c25,c8=rep902.c41,c10=rep902.c42 from rep902 where rep902.years=@years and rep902.distid=T_analy.distid  and (lx is null or lx='汇总数')
update T_analy  set c2=rep902.c1,c5=rep902.c25,c15=rep902.c41,c11=rep902.c42 from rep902 where rep902.years=@years-1 and rep902.distid=T_analy.distid  and (lx is null or lx='汇总数')
update T_analy  set c3=round((c1-c2)*100/c2,2) where c2<>0  and years=@years
update T_analy  set c6=round(c4*100/c1,2) where c1<>0  and years=@years
update T_analy  set c7=round((c4-c5)*100/c4,2) where c4<>0 and years=@years
update T_analy  set c9=round((c8-c15)*100/c8,2) where c8<>0 and years=@years
update T_analy  set c13=round((c10-c11)*100/c11,2) where c11<>0 and years=@years
update T_analy  set c12=c10-c11 where  years=@years
select * from T_analy  where   len(distid)/3<=@cc   order by distid
end
go

