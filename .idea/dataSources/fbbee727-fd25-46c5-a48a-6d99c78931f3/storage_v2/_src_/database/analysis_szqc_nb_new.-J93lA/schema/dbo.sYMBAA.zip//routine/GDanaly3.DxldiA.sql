CREATE proc GDanaly3 (@years int,@distid varchar(50),@cc int)  as
begin 
delete from T_analy

insert into T_analy(years,distid,distname,c2,c3,c5,c7,c9,c10) select years,distid,distname,c1,c9+c13+c15+c17,c19+c20,c22+c23+c24+c21,c1,c42 from rep902 where years=@years  and len(distid)/3<=@cc  and (lx is null or lx='汇总数') and c1<>0
update T_analy  set c1=rep901.c12 from rep901 where rep901.years=@years and rep901.distid=T_analy.distid
update T_analy  set c4=round(c3*100/c2,2) where c2<>0 and years=@years
update T_analy  set c6=round(c5*100/c2,2) where c2<>0 and years=@years
update T_analy  set c8=round(c7*100/c2,2) where c2<>0 and years=@years
update T_analy  set c9=round(c9/c1,0) where c1<>0 and years=@years
update T_analy  set c11=rep905.c2 from rep905 where rep905.years=@years and rep905.distid=T_analy.distid  and lx='汇总数'
update T_analy  set c12=rep906.c28 from rep906 where rep906.years=@years and rep906.distid=T_analy.distid  and lx='汇总数'

select * from T_analy     order by distid
end
go

