CREATE proc GDanaly4 (@years int,@distid varchar(50),@cc int)  as
begin 

delete from T_analy

insert into T_analy(years,distid,distname,c1) select years,distid,distname,c42 from rep902 where years=@years  and len(distid)/3<=@cc and (lx is null or lx='汇总数') and c1<>0
update T_analy  set c2=rep902.c42 from rep902  where rep902.years=@years-1 and rep902.distid=T_analy.distid and (lx is null or lx='汇总数')
update T_analy  set c3=c1-c2 where years=@years 
update T_analy  set c4=round(c3*100/c2,2) where years=@years and c2<>0

select * from T_analy    order by distid
end
go

