CREATE procedure Gdanaly_upload(
	@years int,@distId varchar(50),@distGrade int
) as

declare @analyTable varchar(50)
set @analyTable='uploadAnaly'

delete from t_analy where years=@years and distId like @distId + '%' and len(distId)/3<=@distGrade and analyTable=@analyTable
insert into T_analy(years,distid,distname,analyTable) select years,distid,distname,@analyTable from dist where years=@years and distid like @distid+'%' and len(distid)/3<=@distGrade  order by distId


update t_analy set b1=(select case when count(*)>0 then 1 else 0 end from rep901 where years=t_analy.years and distid=t_analy.distid),
	b2=(select case when count(*)>0 then 1 else 0 end from rep902 where years=t_analy.years and distid=t_analy.distid),
	b3=(select case when count(*)>0 then 1 else 0 end from rep903 where years=t_analy.years and distid=t_analy.distid),
	b4=(select case when count(*)>0 then 1 else 0 end from rep904 where years=t_analy.years and distid=t_analy.distid),
	b5=(select case when count(*)>0 then 1 else 0 end from rep905 where years=t_analy.years and distid=t_analy.distid and lx='汇总数'),
	b6=(select case when count(*)>0 then 1 else 0 end from rep906 where years=t_analy.years and distid=t_analy.distid and lx='汇总数'),
	b7=(select case when count(*)>0 then 1 else 0 end from rep907 where years=t_analy.years and distid=t_analy.distid),
	b8=(select case when count(*)>0 then 1 else 0 end from rep908 where years=t_analy.years and distid=t_analy.distid),
	b9=(select case when count(*)>0 then 1 else 0 end from rep909 where years=t_analy.years and distid=t_analy.distid),
	b10=(select case when count(*)>0 then 1 else 0 end from GD911 where years=t_analy.years and distid=t_analy.distid),
	b11=(select case when count(*)>0 then 1 else 0 end from GD912 where years=t_analy.years and distid=t_analy.distid) ,
b12=(select case when count(*)>0 then 1 else 0 end from rep911 where years=t_analy.years and distid=t_analy.distid) ,
b13=(select case when count(*)>0 then 1 else 0 end from rep912 where years=t_analy.years and distid=t_analy.distid) 
where years=@years and distId like @distId + '%' and len(distId)/3<=@distGrade

select * from t_analy where years=@years and distid like @distid+'%' and len(distid)/3<=@distGrade and analyTable=@analyTable order by distId
go

