


 
 CREATE PROCEDURE [dbo].[_createEmptytable](
       @opttype int, --财务/资产 1为财务,2为资产 对应tabetype 中istype字段
       @distid varchar(100),
       @typeCode varchar(100),
       @years int,
       @beginmonths int,
       @endmonths int,
       @tablename varchar(50)
       )AS
        
       declare @sql varchar(5000)
       declare @sql2 varchar(5000)
       declare @fieldSql varchar(300)
       declare @existsSql varchar(300)
       declare @delsql varchar(5000)
       declare @tabMonths varchar(50)
       declare @whereMonths varchar(200)
       declare @insermonths varchar(50)
       declare @tempmonths int
       declare @revlue int
       declare @existsLx int
       declare @lx varchar(50)
       declare @fieldName varchar(50)
       declare @existsdata int
       declare @roleGrade varchar(10)
        set @tempmonths=@beginmonths
        set @roleGrade=''
   BEGIN
	 if @tablename='' --表不为空，创建当前表，表为空，创建所有表
	  declare basetab cursor for select tablename,isnull(roleGrade,'') as  roleGrade  from fileList where typeCode=@typeCode and years=@years  and  useFlag='是' and tableType='基本表' order by orderId
	else
	  declare basetab cursor for select tablename,isnull(roleGrade,'') as  roleGrade  from fileList where typeCode=@typeCode and years=@years and  useFlag='是'  and tablename=@tablename and tableType='基本表' order by orderId
 	open basetab
	fetch next from basetab into @tablename,@roleGrade
	   
	  while @@FETCH_STATUS=0
	  begin
	  set @tabMonths=''
	  set @whereMonths=''
	  set @insermonths=''
	  set @sql=''
	  set @sql2=''
	  set @beginmonths=@tempmonths
	  set @existsSql=''
	  
	 
	  -----------------------月份
	  while @beginmonths<=@endmonths
	   begin
	  if @beginmonths<>0
	  begin
	    --set @whereMonths=' and years*12+months>=years*12+'+convert(varchar(50),@beginmonths)+' and years*12+months<=years*12+'+convert(varchar(50),@endmonths)
	   set @whereMonths=' and months='+convert(varchar(50),@beginmonths)
	   set @tabMonths=''+convert(varchar(50),@beginmonths)+' as months, ' 
	    set @insermonths=',months'
	   end
	    
	 
	  set @lx=''
	 if exists( select * from fileItemLink where tableName=@tablename and years=@years)
	   set @existsLx=1
	   else
	   set @existsLx=0
	   
	  if @existsLx<>0
	  set @lx=',dd.lx,dd.lxid,dd.lxname'
	--  select @existsdata=COUNT(id) from distEx where tableName=@tablename
   --  if @existsdata>0
	 -- begin 
	  if @opttype=1 --财务
	   begin
	   --不做删除操作
		   --set @delsql='delete from '+ @tablename +' where years='+convert(varchar(50),@years)+@whereMonths+ ' and distid like '''+@distid+'%'' and saveflag=''否'''
		 --  exec(@delsql)
		  -- print @delsql
		   if @existsLx=0
			   begin
			   set @sql='insert into '+@tablename+'( years'+@insermonths+',distid,distname,gradeid,balflag,saveflag,
			    sumflag,isold_data)select '+convert(varchar(50),@years)+' as years,'+@tabMonths+'  d.distId,d.distname,
			    distType,''否'' as balflag,''否'' as saveflag,''否'' as  sumflag,0 as isold_data  
			    from dist d left join ['+@tablename+'] r	 on d.years=r.years '+@whereMonths+' and d.distid=r.distId  
			    where  d.years='+convert(varchar(50),@years)+' and  d.distId like '''+@distid+'%''   
			     and len(d.distId) =(select max(LEN(distid)) from dist where years='+convert(varchar(50),@years)+')  
			     and r.distid is null'
			   end
		   else
			   begin
		    
			   set @sql='if exists(select * from distEx where years='+convert(varchar(50),@years)+' 
			   and distid like case when '''+@distid+'''=''0'' then ''%'' else '''+@distid+'%'' end   
			   and  tableName='''+@tablename+''')
			   insert into '+@tablename+'( years'+@insermonths+', distid,distname,acc_set,ztid'+@lx+',isold_data,gradeid,
			   balflag,saveflag, sumflag) select '+ convert(varchar(50),@years) +' as years,'+@tabMonths+' dd.distId,
			   dd.distname,dd.acc_set,dd.ztid'+@lx+' ,0 as isold_data,dd.distType as gradeid,''否'' as balflag,
			   ''否'' as saveflag,''否'' as  sumflag 
			    from (select d.*,t.distType from distEx d,dist t where d.years ='+convert(varchar(50),@years)+' 
			    and d.distId like '''+@distid+'%'' and tableName='''+@tablename+''' and d.years=t.years 
			    and d.distid=t.distid)dd left join '+@tablename+' r on dd.distid=r.distid and dd.acc_set=r.acc_set 
			    and dd.years=r.years '+@whereMonths+' and dd.lx=r.lx and dd.lxname=r.lxname 
			    where r.distid is null'
				end
			   exec(@sql)	
			--   print @sql 
			  	  
			 --处理非底级数据
			 
			 if @existsLx=0
			 begin
			  set @sql2=''
			  set @sql2='insert into '+@tablename+'( years '+@insermonths+',distid,distname,gradeid,balflag,saveflag, sumflag)select '+convert(varchar(50),@years)+' as years ,'+@tabMonths+' distid,distname,d.distType as gradeid,''否'' as balflag,''否'' as saveflag,''是'' as  sumflag from dist d where   not exists(select distId  from '+@tablename+' r where r.distid=d.distId and r.years=d.years '+@whereMonths+') and years='+convert(varchar(50),@years) --+' and len(d.distId) =(select max(LEN(distid)) from dist where years='+convert(varchar(50),@years)+')'
				 exec (@sql2)
			--	 print @sql2
				end 
	     end
	     
	     
	     ---
         if @opttype=2   --年报 资产
		   begin
		   declare @icount int
		   select  @icount=COUNT(*)   from dist d inner join tabinLimit t
										on d.years=t.years and d.distId like t.distid+'%' and d.disttype=t.grade
			where d.years=@years  and d.distid like @distid+'%'
		   if @existsLx=0
			begin
			 if @icount>0
				begin
				 set @sql2='insert into '+@tablename+'( years '+@insermonths+
						',distid,distname,gradeid,balflag,saveflag, sumflag)
				  select '+CONVERT(varchar(50),@years)+' as years,'++@tabMonths++' d.distid,d.distname,
				  d.distType as gradeid,''否'' as balflag,''否'' as saveflag,''否'' as  sumflag
				  from dist d 
				   inner join (select * from tabinlimit where visible=1 and  years='+CONVERT(varchar(50),@years)
								 +')i
						on d.distId like i.distid+''%'' and d.distType=i.grade
				   left join (select years,distId  from '+@tablename+' where years='+CONVERT(varchar(50),@years)+') r 
						on d.years=r.years and d.distId=r.distid
				 where  d.years='+CONVERT(varchar(50),@years)+'					  
					 and d.distId like case when '''+@distid+'''=''0'' then ''%'' else '''+@distid+'%'' end   
					 and r.distid is null'
				 exec(@sql2)
				 set @sql2=''
				 end
				 
				 
				 if @roleGrade='' or @roleGrade='村'
					begin
						set @sql2='insert into '+@tablename+'( years '+@insermonths+
						',distid,distname,gradeid,balflag,saveflag, sumflag)
						 select '+convert(varchar(50),@years)+' as years , d.distid,d.distname,d.distType as gradeid,
						 ''否'' as balflag,''否'' as saveflag,''否'' as  sumflag
						 from dist d  
						 left join (select years,distId  from '+@tablename+' where years='+convert(varchar(50),@years)+') r 
						 on d.years=r.years and d.distId=r.distid
						 left join (select d.* from dist d,tabinlimit t
						 		 where d.years='+convert(varchar(50),@years)+'	and d.years=t.years and visible=1
						 		  and  t.years='+convert(varchar(50),@years)+' and d.distId like t.distid +''%'')dt
						 on d.years=dt.years and d.distId=dt.distId
					where  d.years='+convert(varchar(50),@years)+'	
					and d.distId like case when '''+@distid+'''=''0'' then ''%'' else '''+@distid+'%'' end  
					and LEN(d.distId)>=9	and dt.distId is  null 	and r.distid is null
						'
						
					exec(@sql2)
					set @sql2=''
					end
				 end
		   else
		   begin
           --有类型的表,根据fileItemLinkexex表分两种形式 
		   if exists (select * from fileItemLinkExEx 
					 where years=CONVERT(varchar(20),@years) and tableName=''+@tablename+'')
		   begin
			set @sql2='insert into '+@tablename+'( years '+@insermonths+',distid,distname,gradeid,lx,lxid,lxname,
			balflag,saveflag, sumflag)
			select '+convert(varchar(50),@years)+' as years ,'+@tabMonths+'dd.distid,dd.distname,
			dd.distType as gradeid,dd.prjItem as lx,l.lxid as lxid,(dd.distname+dd.prjItem) as lxname,
			''否'' as balflag,''否'' as saveflag,''否'' as  sumflag 
			from (select d.*,ex.prjItem from dist d inner join (select d.* 
									from (select years,LEN(distid) lens,distType from dist 
									where years='+CONVERT(varchar(20),@years)+' group by years,LEN(distid),distType) d 
									inner join filelist f
									on d.years=f.years and d.distType=f.roleGrade  
									and f.tableType=''基本表'' and f.tableName='''+@tablename+''')dd
									on d.years=dd.years and len(d.distId)<=dd.lens 
								inner join 	fileItemLinkExex ex
										on  d.years=ex.years and d.distType=ex.distType 
										and ex.tableName='''+@tablename+'''
						where d.years='+CONVERT(varchar(20),@years)+' 
								and d.distId like case when '''+@distid+'''=''0''  then ''%'' else '''+@distid+'%'' end   
								and ex.tablename='''+@tablename+''')dd 
			left join '+@tablename+'  r  on  dd.years=r.years and dd.distid=r.distId 
			left join lxorder l 
			on l.years='+convert(varchar(50),@years)+' and l.typeCode='''+@typeCode+''' and l.lx=dd.prjItem
			 where  r.distid is null'
			end
		   else
			begin
			--是否在判断单位表distex
			set @sql2='if exists(select * from distEx where years='+convert(varchar(50),@years)+' 
								and distid like '''+@distid+'%'' and tableName='''+@tablename+''')
			insert into '+@tablename+'( years '+@insermonths+',distid,distname,acc_set,ztid'+@lx+',
			gradeid,balflag,saveflag, sumflag ) 
			select '+ convert(varchar(50),@years) +' as years,'+@tabMonths+'dd.distId,dd.distname,dd.acc_set,
				dd.ztId'+@lx+',dd.distType as gradeid,''否'' as balflag,''否'' as saveflag,''否'' as sumflag 
			from (select d.*,t.distType  from distEx d,dist t 
					where d.years='+convert(varchar(50),@years)+' 
					and d.distId like  case when '''+@distid+'''=''0'' then ''%'' else '''+@distid+'%''end  
					and  tableName='''+@tablename+''' and d.years=t.years  and d.distid=t.distid)dd 
			left join '+@tablename+' r
			 on  dd.distid=r.distid and dd.years=r.years and dd.lx=r.lx and dd.lxname=r.lxname
			where r.distid is null and r.lx is null'
			end
		end
			  exec (@sql2)
			  set @sql2=''
		end
         
         
         if @opttype=3  --资产
		   begin
		   if @existsLx=0
			begin
				if @roleGrade='' or @roleGrade='村'
				set @sql2='insert into '+@tablename+'( years '+@insermonths+
				',distid,distname,gradeid,balflag,saveflag, sumflag)
				 select '+convert(varchar(50),@years)+' as years ,'+@tabMonths+
				 ' distid,distname,d.distType as gradeid,''否'' as balflag,''否'' as saveflag,''否'' as  sumflag 
					from dist d where   not exists(select distId  from '+@tablename+
					' r where r.distid=d.distId and r.years=d.years '+@whereMonths+') 
					and years='+convert(varchar(50),@years)+' and distId like '''+@distid+'%'' and LEN(distid)>=9'
				 end
		   else
		   begin
           --有类型的表,根据fileItemLinkexex表分两种形式 
		   if exists (select * from fileItemLinkExEx 
					 where years=CONVERT(varchar(20),@years) and tableName=''+@tablename+'')
		   begin
			set @sql2='insert into '+@tablename+'( years '+@insermonths+',distid,distname,gradeid,lx,lxid,lxname,balflag,saveflag, sumflag)select '+convert(varchar(50),@years)+' as years ,'+@tabMonths+' dd.distid,dd.distname,dd.distType as gradeid,dd.prjItem as lx,(select distinct lxid from lxorder where lxorder.years=dd.years and lxorder.lx=dd.prjItem) as lxid,(dd.distname+dd.prjItem) as lxname,''否'' as balflag,''否'' as saveflag,''否'' as  sumflag 
				from (select d.*,ex.prjItem from dist d,fileItemLinkExex ex 
			where d.years='+CONVERT(varchar(20),@years)+' and d.distId like case when '''+@distid+'''=''0'' then ''%'' else '''+@distid+'%'' end  
			 and LEN(distid)<=9 and ex.tablename='''+@tablename+''' and d.years=ex.years and d.distType=ex.distType			
			)dd left join '+@tablename+' r  on  dd.years=r.years and dd.distid=r.distId  where   r.distid is null'
			 
			 end
		   else
			begin
			--是否在判断单位表distex
			set @sql2='if exists(select * from distEx where years='+convert(varchar(50),@years)+' and distid like '''+@distid+'%'' and tableName='''+@tablename+''')insert into '+@tablename+'( years '+@insermonths+',distid,distname,acc_set,ztid'+@lx+',gradeid,balflag,saveflag, sumflag ) select '+ convert(varchar(50),@years) +' as years,'+@tabMonths+'dd.distId,dd.distname,dd.acc_set,dd.ztId'+@lx+',dd.distType as gradeid,''否'' as balflag,''否'' as saveflag,''否'' as sumflag from (select d.*,t.distType  from distEx d,dist t where 
		d.years='+convert(varchar(50),@years)+' and d.distId like  case when '''+@distid+'''=''0'' then ''%'' else '''+@distid+'%''end  and  tableName='''+@tablename+''' and d.years=t.years  and d.distid=t.distid 
					 )dd left join '+@tablename+' r on  dd.distid=r.distid and dd.years=r.years and dd.lx=r.lx and dd.lxname=r.lxname
							  where r.distid is null and r.ztid is null
					 '
			end
		end
			  exec (@sql2)
			  set @sql2=''
			 -- print @sql2
			 	  
			 --处理非底级数据
			 
			 if @existsLx=0
			 begin
			  set @sql2=''
			  if @roleGrade='镇'
			  set @sql2='insert into '+@tablename+'( years '+@insermonths+',distid,distname,gradeid,balflag,saveflag, sumflag)select '+convert(varchar(50),@years)+' as years ,'+@tabMonths+' distid,distname,d.distType as gradeid,''否'' as balflag,''否'' as saveflag,''是'' as  sumflag 
				  from dist d 		  
			  where   not exists(select distId  from '+@tablename+' r where r.distid=d.distId and r.years=d.years '+@whereMonths+') and years='+convert(varchar(50),@years)+' and distId like '''+@distid+'%'' and LEN(distid)<9'
				  exec (@sql2)
				  set @sql2=''
			--	print @sql2
				end 
			

         end
         
         --if @beginmonths<>0 -----------------
         -- begin
          --set @whereMonths=' and months='+CONVERT(varchar(50),@beginmonths)
         -- end 
         -- else
         -- begin
         -- set @whereMonths=''
         -- end
          --去空值
          
          set @beginmonths=@beginmonths+1
          end---------------------------月份 
           set @existsSql='if exists(select * from '+@tablename+' where years='+convert(varchar(50),@years)+@whereMonths+' )exec dbo.removeEmpty '''+@distid+''','''+@typeCode+''','+convert(varchar(50),@years)+','+convert(varchar(50),@tempmonths)+','+convert(varchar(50),@endmonths)+','''+@tablename+''''
            exec (@existsSql)
          -- print @existsSql
           -- end
           --set @beginmonths=@beginmonths+1
            -- end---------------------------月份  
	  fetch next from basetab into @tablename,@roleGrade
	  end
	
	  close basetab
      deallocate basetab
END

 go

