 
 
--生成空表储存
       CREATE PROCEDURE [dbo].[_createEmptytable](
       @opttype int, --财务/资产 1为财务,2为资产 对应tabetype 中istype字段
       @distid varchar(100),
       @typeCode varchar(100),
       @years int,
       @beginmonths int,
       @endmonths int,
       @tablename varchar(50)
       )AS
        
       declare @sql varchar(5000)
       declare @sql2 varchar(5000)
       declare @fieldSql varchar(300)
       declare @existsSql varchar(300)
       declare @delsql varchar(5000)
       declare @tabMonths varchar(50)
       declare @whereMonths varchar(200)
       declare @insermonths varchar(50)
       declare @tempmonths int
       declare @revlue int
       declare @existsLx int
       declare @lx varchar(50)
       declare @fieldName varchar(50)
       declare @existsdata int
       declare @roleGrade varchar(10)
        set @tempmonths=@beginmonths
        set @roleGrade=''
   BEGIN
	 if @tablename='' --表不为空，创建当前表，表为空，创建所有表
	  declare basetab cursor for select tablename,roleGrade from fileList where typeCode=@typeCode and years=@years and tableType='基本表' order by orderId
	else
	  declare basetab cursor for select tablename,roleGrade from fileList where typeCode=@typeCode and years=@years and tablename=@tablename and tableType='基本表' order by orderId
 	open basetab
	fetch next from basetab into @tablename,@roleGrade
	   
	  while @@FETCH_STATUS=0
	  begin
	  set @tabMonths=''
	  set @whereMonths=''
	  set @insermonths=''
	  set @sql=''
	  set @sql2=''
	  set @beginmonths=@tempmonths
	  set @existsSql=''
	  
	 
	  -----------------------月份
	  while @beginmonths<=@endmonths
	   begin
	  if @beginmonths<>0
	  begin
	    --set @whereMonths=' and years*12+months>=years*12+'+convert(varchar(50),@beginmonths)+' and years*12+months<=years*12+'+convert(varchar(50),@endmonths)
	   set @whereMonths=' and months='+convert(varchar(50),@beginmonths)
	   set @tabMonths=''+convert(varchar(50),@beginmonths)+' as months, ' 
	    set @insermonths=',months'
	   end
	    
	 
	  set @lx=''
	 if exists( select * from fileItemLink where tableName=@tablename and years=@years)
	   set @existsLx=1
	   else
	   set @existsLx=0
	   
	  if @existsLx<>0
	  set @lx=',lx,lxid,lxname'
	--  select @existsdata=COUNT(id) from distEx where tableName=@tablename
   --  if @existsdata>0
	 -- begin 
	  if @opttype=1 --财务
	   begin
	   --不做删除操作
		   --set @delsql='delete from '+ @tablename +' where years='+convert(varchar(50),@years)+@whereMonths+ ' and distid like '''+@distid+'%'' and saveflag=''否'''
		 --  exec(@delsql)
		  -- print @delsql
		   if @existsLx=0
			   begin
			   set @sql='insert into '+@tablename+'( years'+@insermonths+',distid,distname,gradeid,balflag,saveflag, sumflag,isold_data)select '+convert(varchar(50),@years)+' as years,'+@tabMonths+'  t.distId,t.distname,distType,''否'' as balflag,''否'' as saveflag,''否'' as  sumflag,0 as isold_data  from dist t where  t.distId like '''+@distid+'%'' and t.years='+convert(varchar(50),@years)+' and not exists(select * from ['+@tablename+'] r where r.distid=t.distid and r.years=t.years '+@whereMonths+')  and len(t.distId) =(select max(LEN(distid)) from dist where years='+convert(varchar(50),@years)+') and len(t.distId) =(select max(LEN(distid)) from dist where years='+convert(varchar(50),@years)+')'
			   end
		   else
			   begin
		    
			   set @sql='if exists(select * from distEx where tableName='''+@tablename+''' and years='+convert(varchar(50),@years)+')insert into '+@tablename+'( years'+@insermonths+', distid,distname,acc_set,ztid'+@lx+',isold_data,gradeid,balflag,saveflag, sumflag) select '+ convert(varchar(50),@years) +' as years,'+@tabMonths+' d.distId,t.distname,d.acc_set,d.ztid'+@lx+' ,0 as isold_data,t.distType as gradeid,''否'' as balflag,''否'' as saveflag,''否'' as  sumflag  from distEx d,dist t where tableName='''+@tablename+''' and not exists(select * from ['+@tablename+'] r where r.distid=d.distid and r.acc_set=d.acc_set and r.years=d.years '+@whereMonths+' and lx=d.lx and lxname=d.lxname ) and d.years ='+convert(varchar(50),@years)+' and d.years=t.years and d.distId like '''+@distid+'%'' and d.distid=t.distid'
				end
			   exec(@sql)	
			   --print @sql 
			  	  
			 --处理非底级数据
			 
			 if @existsLx=0
			 begin
			  set @sql2=''
			  set @sql2='insert into '+@tablename+'( years '+@insermonths+',distid,distname,gradeid,balflag,saveflag, sumflag)select '+convert(varchar(50),@years)+' as years ,'+@tabMonths+' distid,distname,d.distType as gradeid,''否'' as balflag,''否'' as saveflag,''是'' as  sumflag from dist d where   not exists(select distId  from '+@tablename+' r where r.distid=d.distId and r.years=d.years '+@whereMonths+') and years='+convert(varchar(50),@years) --+' and len(d.distId) =(select max(LEN(distid)) from dist where years='+convert(varchar(50),@years)+')'
				 exec (@sql2)
				end 
	     end
	     
	     
	     ---
         if @opttype=2 or @opttype=3  --资产
         begin
			if @existsLx=0
			 begin
			 if @roleGrade='' or @roleGrade='村'
			 set @sql2='insert into '+@tablename+'( years '+@insermonths+',distid,distname,gradeid,balflag,saveflag, sumflag)
			 select '+convert(varchar(50),@years)+' as years ,'+@tabMonths+' distid,distname,d.distType as gradeid,''否'' as balflag,''否'' as saveflag,''否'' as  sumflag from dist d where   not exists(select distId  from '+@tablename+' r where r.distid=d.distId and r.years=d.years '+@whereMonths+') and years='+convert(varchar(50),@years)  +' and distId like '''+@distid+'%'' and LEN(distid)>=9'
			 end
			 else
			 begin
         			 
			 --有类型的表 是否在判断单位表distex
			 set @sql2='if exists(select * from distEx where tableName='''+@tablename+''' and years='+convert(varchar(50),@years)+')insert into '+@tablename+'( years '+@insermonths+',distid,distname,acc_set,ztid'+@lx+',gradeid,balflag,saveflag, sumflag ) select '+ convert(varchar(50),@years) +' as years,'+@tabMonths+'d.distId,t.distname,d.acc_set,d.ztId'+@lx+',t.distType as gradeid,''否'' as balflag,''否'' as saveflag,''否'' as sumflag from distEx d,dist t where tableName='''+@tablename+''' and d.years ='+convert(varchar(50),@years)
			 +' and d.years=t.years and  not exists(select id from ['+@tablename +'] r where r.distid=d.distid  and  years='+convert(varchar(50),@years) +@whereMonths+' and r.lx=d.lx and r.lxname=d.lxname )  and d.distId like '''+@distid+'%'' and d.distid=t.distid
			 '
			 end
			  exec (@sql2)
			 -- print @sql2
			 	  
			 --处理非底级数据
			 
			 if @existsLx=0
			 begin
			  set @sql2=''
			  if @roleGrade='镇'
			  set @sql2='insert into '+@tablename+'( years '+@insermonths+',distid,distname,gradeid,balflag,saveflag, sumflag)select '+convert(varchar(50),@years)+' as years ,'+@tabMonths+' distid,distname,d.distType as gradeid,''否'' as balflag,''否'' as saveflag,''是'' as  sumflag from dist d where   not exists(select distId  from '+@tablename+' r where r.distid=d.distId and r.years=d.years '+@whereMonths+') and years='+convert(varchar(50),@years)+' and distId like '''+@distid+'%'' and LEN(distid)<9'
				  exec (@sql2)
				--print @sql2
				end 
			

         end
         --if @beginmonths<>0 -----------------
         -- begin
          --set @whereMonths=' and months='+CONVERT(varchar(50),@beginmonths)
         -- end 
         -- else
         -- begin
         -- set @whereMonths=''
         -- end
          --去空值
          
          set @beginmonths=@beginmonths+1
          end---------------------------月份 
           set @existsSql='if exists(select * from '+@tablename+' where years='+convert(varchar(50),@years)+@whereMonths+' )exec dbo.removeEmpty '''+@distid+''','''+@typeCode+''','+convert(varchar(50),@years)+','+convert(varchar(50),@tempmonths)+','+convert(varchar(50),@endmonths)+','''+@tablename+''''
            exec (@existsSql)
          -- print @existsSql
           -- end
           --set @beginmonths=@beginmonths+1
            -- end---------------------------月份  
	  fetch next from basetab into @tablename,@roleGrade
	  end
	
	  close basetab
      deallocate basetab
END
go

