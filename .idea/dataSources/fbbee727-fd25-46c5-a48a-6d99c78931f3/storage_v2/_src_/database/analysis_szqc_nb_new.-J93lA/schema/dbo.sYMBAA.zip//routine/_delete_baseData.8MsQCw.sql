create  PROCEDURE [dbo]._delete_baseData(
@years int,
@months int,
@distNo varchar(20),
@isdeteleBaseData int 
)as
declare @tablename varchar(50),@sql varchar(4000),@tabletype varchar(20),@optType int,@counts int
set @sql=''
set @counts=0
set @tabletype='三资清查'

if @isdeteleBaseData=0
select @counts=COUNT(*)  from uploadBase where years=CONVERT(varchar(10),@years) and ISNULL(months,0)=CONVERT(varchar(10),@months) and distno = ''+@distNo+'' and okflag=1 and tableType=''+@tabletype+''
if @isdeteleBaseData=1
select @counts=COUNT(*)  from uploadBase where years=CONVERT(varchar(10),@years) and ISNULL(months,0)=CONVERT(varchar(10),@months) and distno like ''+@distNo+'%' and okflag=1 and tableType=''+@tabletype+''

if @counts=0
	begin
	declare fortab cursor for
	 select f.tablename,t.optType from filelist f,tabletype t  where f.years=convert(varchar(10),@years) and f.typecode=''+@tabletype+'' 
	 and isDeleteTab=1 and f.typecode=t.tabletype and f.tabletype='基本表'
	 open fortab
	 fetch next from fortab into @tablename,@optType
	 while @@fetch_status=0
	 begin
		set @sql=' delete from  '+@tablename+' where years='+CONVERT(varchar(10),@years)
	    if @optType=2 or @optType=3
	    set @sql=@sql+' and ISNULL(months,0)='+CONVERT(varchar(10),@months)
	    if @isdeteleBaseData=1
	    set @sql=@sql+' and distid like '''+@distNo+'''%'''
	    if @isdeteleBaseData=0
	     set @sql=@sql+' and distid = '''+@distNo+''''
	     
	     set @sql=@sql+' and okflag=0 and isnull(saveflag,'''')<>''是'''
	    exec (@sql)
	  
	 fetch next from fortab into @tablename,@optType
	 end
	 close fortab
	 deallocate fortab
	 end
go

