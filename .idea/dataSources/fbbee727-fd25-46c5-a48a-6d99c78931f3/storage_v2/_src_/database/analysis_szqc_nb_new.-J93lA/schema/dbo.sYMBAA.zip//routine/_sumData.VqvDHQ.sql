
 
 

CREATE PROCEDURE [dbo].[_sumData](
--declare
  @years int,
  @months int,
  @tableType varchar(50),
  @tableName varchar(50),
  @distId varchar(50),
  @distType int,    --1 所有地区,2当前地区(及下级地区),4当前地区(只含本级)
  @distLength int, --为0
  @existsDataType int --1 覆盖原有汇总数
) as

/*
set @years=2012
set @months=0
set @tableType='年报'
set @tableName='nh904'
set @distId='001003'
set @distType=4        --地区类型
set @distLength=0   --无用
set @existsDataType=1  --存在数据是否删除
*/




declare @maxDistIdLength int
declare @tmpInt int
declare @sql varchar(8000)
declare @processSql varchar(8000)

declare @sumColumns varchar(8000)
declare @columns varchar(8000)
declare @columnName varchar(50)
declare @existsLx bit
declare @tmpBit bit
declare @parentLx varchar(50)
declare @parentLxId int
declare @er int
--begin tran

  select @maxDistIdLength=max(len(distid)) from dist where years=@years and distId like @distId + '%'
    
   
  if @distType=4
   if @distId=''
   select @maxDistIdLength=max(len(distid)) from dist where years=@years and distId ='0'
   else
   select @maxDistIdLength=max(len(distid)) from dist where years=@years and distId like @distId + '%'
  
  if @tableName=''
    declare hzCur cursor for select tableName from filelist where typecode=@tableType and years=@years and tableType='基本表' and tablename<>'nh907b' and tablename<>'nh907c'
  else
    declare hzCur cursor for select tableName from filelist where typecode=@tableType and years=@years and tableType='基本表' and tableName=@tableName and tablename<>'nh907b' and tablename<>'nh907c'
  open hzCur
  fetch next from hzCur into @tableName
  set @er=@@FETCH_STATUS
  while @@fetch_status=0
  begin
    if exists(select * from fileItemLink where tableName=@tableName and years=@years)
      set @existsLx = 1
    else
      set @existsLx = 0

    --------------------------------------------
    set @columns = ''
    set @sumColumns = ''
    declare colCur cursor for select fieldName from fileItem where tableName=@tableName and years=@years and rtrim(fType)='N' and disFlag=1 order by disId
    open colCur
    fetch next from colCur into @columnName
    while @@fetch_status=0
    begin
      if @columns <> '' set @columns = @columns + ','
      if @sumColumns <> '' set @sumColumns = @sumColumns + ','

      set @columns = @columns + @columnName
      set @sumColumns = @sumColumns + 'sum(' + @columnName + ') as ' + @columnName

      fetch next from colCur into @columnName
    end
    close colCur
    deallocate colCur

    ---------------------------------------------
    set @tmpBit = 0
    if @distType=4
      set @tmpBit = 1

    if (@distType=1) or (@distType=2) or (@distType=4)  
    begin
      if @existsDataType = 1
      begin
        set @sql = 'delete from ' + @tableName + ' where years=' + convert(varchar(4),@years)
        if @months<>0
			set @sql = @sql + ' and months=' + convert(varchar(2),@months)
        set @sql = @sql + ' and saveFlag<>''是'' and sumFlag=''是'' and '
        
		if @distType = 4
			begin
				if @distId=''
					set @sql = @sql + 'distId=''0'''
				else
					set @sql = @sql + 'distId=''' + @distId + ''''
			end
		else
			set @sql = @sql + 'distId like ''' + @distId + '%'''
			
        if @existsLx = 1
        begin
          set @sql = @sql + ' and (charindex(''汇总数'',lxname)<>0 or (select count(*) from ' + @tableName + ' aaa where aaa.years=' + @tableName + '.years and '
          if @months<>0
            set @sql = @sql + 'months=' + convert(varchar(2),@months) + ' and '
		  set @sql = @sql + 'aaa.lx=' + @tableName + '.lx and aaa.distId<>' + @tableName + '.distId and aaa.distId like ' + @tableName + '.distId + ''%'')>0 or ' +
			'(lxname=distname+lx and (select count(*) from ' + @tableName + ' aa where years=' + convert(varchar(4),@years)
		  if @months<>0
            set @sql = @sql + ' and months=' + convert(varchar(2),@months)
		  set @sql = @sql + ' and distId='+ @tableName +'.distId and aa.lx=' + @tableName + '.lx)>1))' 
        end
		else
			set @sql = @sql + ' and ((select count(*) from ' + @tableName + ' aaa where aaa.years=' + @tableName + '.years and ' + 
				'aaa.distId<>' + @tableName + '.distId and aaa.distId like ' + @tableName + '.distId + ''%'')>0)'
		  exec(@sql)
		 --print @sql
		 print @sql
	 
	  end
      
	  --基础模式	   
      set @tmpInt=@maxDistIdLength
      while len(@distid)<=@tmpInt
      begin
		--set @tmpInt = len(@distId)
		 if @tmpInt=1
			  begin
			  exec _sumoffbeat @tableType,@years,@months,@tableName,@distId,@columns,@sumColumns,@tmpInt,@maxDistIdLength,0,1,'',0,@existsDataType,@existsLx,@tmpBit,''
			   end
			  else
        exec _sumBaseData @tableType,@years,@months,@tableName,@distId,@columns,@sumColumns,@tmpInt,@maxDistIdLength,0,1,'',0,@existsDataType,@existsLx,@tmpBit,''
        
		if @existsLx = 1
		begin  
			--南海村级汇总数（经联社+村（居）委)
			declare lxcur cursor for select parentLx,parentLxId from (select parentLx,(select lxid from lxorder a where a.lx=lxorder.parentLx and a.years=lxorder.years and a.typecode=lxorder.typecode) parentLxId from lxorder where years=@years and typecode=@tableType and parentlx is not null and parentLx<>'' group by parentlx,years,typeCode) aaa order by parentLxId desc
			open lxcur
			fetch next from lxcur into @parentLx,@parentLxId
			while @@fetch_status=0
			begin
			 if @tmpInt=1
			  begin
			  exec _sumoffbeat @tableType,@years,@months,@tableName,@distId,@columns,@sumColumns,@tmpInt,@maxDistIdLength,0,1,'',0,@existsDataType,@existsLx,@tmpBit,@parentLx
			   end
			  else
				exec _sumBaseData @tableType,@years,@months,@tableName,@distId,@columns,@sumColumns,@tmpInt,@maxDistIdLength,0,1,'',0,@existsDataType,@existsLx,@tmpBit,@parentLx
				fetch next from lxcur into @parentLx,@parentLxId
			end
			close lxcur
			deallocate lxcur
		end
		
		--set @tmpInt = @tmpInt - 3
		set @tmpInt=(select top 1 LEN(distId) from dist where LEN(distId)<@tmpInt group by LEN(distId) order by LEN(distId) desc)
	  end
        
        
      --  set @tmpInt = @tmpInt - 3
      --end
      
      if @existsLx = 1
      begin
		--经济社汇总数
		if @distid=''
		begin
		exec _sumoffbeat  @tableType,@years,@months,@tableName,@distId,@columns,@sumColumns,@tmpInt,@maxDistIdLength,0,0,'汇总数',1,@existsDataType,@existsLx,@tmpBit,''
		end
		else
        exec _sumBaseData @tableType,@years,@months,@tableName,@distId,@columns,@sumColumns,@tmpInt,@maxDistIdLength,0,0,'汇总数',1,@existsDataType,@existsLx,@tmpBit,''
        
		
        --汇总数
        if @distid=''
			  begin
			  exec _sumoffbeat @tableType,@years,@months,@tableName,@distId,@columns,@sumColumns,@tmpInt,@maxDistIdLength,0,0,'汇总数',0,@existsDataType,@existsLx,@tmpBit,''
			   end
			  else
        exec _sumBaseData @tableType,@years,@months,@tableName,@distId,@columns,@sumColumns,@tmpInt,@maxDistIdLength,0,0,'汇总数',0,@existsDataType,@existsLx,@tmpBit,''
      end
    end

    set @sql = 'update ' + @tableName + ' set gradeId=dist.distType from dist where ' + @tableName + '.years=dist.years and ' + @tableName + '.years=' +
	convert(varchar(4),@years) + ' and ' + @tableName + '.distId=dist.distId and ' + @tableName + '.distId'
    if @distType = 4
	set @sql = @sql + '=''' + @distId + ''''
    else
	set @sql = @sql + ' like ''' + @distId + '%'''
      exec(@sql)
     --print @sql
     print @sql


    declare hzRun cursor for select processSql from dataProcess where hzRun=1 and tableType=@tableType and years=@years order by orderId
    open hzRun
    fetch next from hzRun into @processSql
    while (@@fetch_status=0)
    begin
      set @sql = @processSql

      set @sql = replace(@sql, ':年', convert(varchar(4),@years))
      set @sql = replace(@sql, ':月', convert(varchar(4),@months))
      set @sql = replace(@sql, ':地区', @distId)
      set @sql = replace(@sql, ':id', '0')
      set @sql = replace(@sql, '#tableType#', @tableType)
      set @sql = replace(@sql, '#distType#', convert(varchar(4),@distType))

      exec(@sql)
       --print @sql
		print @sql
      fetch next from hzRun into @processSql
    end
    close hzRun
    deallocate hzRun

  
    fetch next from hzCur into @tableName
  end
  close hzCur
  deallocate hzCur
--commit tran


go

