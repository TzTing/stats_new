CREATE  procedure [dbo].[_sumoffbeat_20190718前]
(
   @tableType varchar(50),  ---模式
   @years int,              ---年份
   @months int,             ---月份
   @tableName varchar(50),  ---表名
   @distId varchar(50),     ---地区代码
   @columns varchar(8000),  --fileitem 列  c1,c2,c3
   @sumColumns varchar(8000), --fileitem 合计列  sum(c1),sum(c2),sum(c3)
   @distIdInt int,  --地区长度
   @maxDistIdInt int,  --最大地区长度
   @distIdLen int,  --值：0
   @distIdType int,   --类型，基础数：1，汇总数：0
   @lx varchar(50),   --类型名称   基础数：‘’，汇总数：‘汇总数’
   @isHzsOtherLx bit,  --是否汇总其他类型		基础数：0，汇总数 1,经联社汇总数
   @existsDataType int,   --存在数据的覆盖方式
   @existsLx bit,  --是否存在数据类型
   @linkDist bit,	--where 语句 link 地区
   @parentLx varchar(50)  --基础模式（非任何汇总数） 名称从lxorder的parentLx
) as
begin
  declare @sql varchar(8000)
  declare @colSql varchar(4000)
  declare @insertSql varchar(2000)
  set @colSql=''
  ------------- @insertSql
  set @insertSql = 'insert into ' + @tableName + '(years,'
  if @months<>0
  begin
  set @insertSql = @insertSql + 'months,'
  end
    
  set @insertSql = @insertSql + 'saveFlag,sumFlag,balFlag,distId,distName,'
  
  if @existsLx = 1
  begin
   set @insertSql = @insertSql + 'lx,lxname,lxid,'
  end
  
  set @insertSql = @insertSql + @columns + ') '
----------------------------------------------@insertSql
  set @colSql='select years,'
  set @sql ='select years,'
  if @months<>0
  begin
	set @colSql=@colSql+'months,'
	set @sql = @sql+'months,'
  end
  set @colSql=@colSql+ '''否'' as saveFlag,''是'' as sumFlag,''否'' as balFlag,'
  set @sql = @sql + '''否'' as saveFlag,''是'' as sumFlag,''否'' as balFlag,'

  if @lx<>'汇总数'
  begin
    set @colSql=@colSql+'distid,distName'
    set @sql = @sql + '(select top 1 distid from dist where years=' + convert(varchar(4),@years) 
				+' and len(distid)='+ convert(varchar(40),@distIdInt) +') as distId,(select top 1 distName from dist where years=' 
				+ convert(varchar(4),@years) +' and len(distId)='+ convert(varchar(40),@distIdInt) + ') as distName '
    if @existsLx = 1
    begin
	  --lxorder parentLx
	  if @parentLx=''
	  begin
	   set @colSql=@colSql+',lx' 
	   set @sql = @sql + ',lx' 
	  end
	  else 
	  begin
	   set @colSql=@colSql+ ',''' + @parentLx + ''' as lx'
	   set @sql = @sql + ',''' + @parentLx + ''' as lx'
	  end
      set @sql = @sql + ',(select top 1 distName from dist where years=' + convert(varchar(4),@years) +' and len(distId)=' + convert(varchar(40),@distIdInt)+') + '
		
	  if @parentLx='' set @sql = @sql + 'lx' else set @sql = @sql + '''' + @parentLx + ''''
	  set @colSql=@colSql+',lxname,lxid' 
	  set @sql = @sql + ' as lxname,(select lxid from lxorder where typeCode=''' + @tableType+''' and years=' + convert(varchar(4),@years)
		
	  if @parentLx=''
		set @sql = @sql + ' and lx=' + @tableName + '.lx) as lxid'
	  else
		set @sql = @sql + ' and lx=''' + @parentLx + ''') as lxid'
	end
  end
 
 
 --=====================================================3汇
  else
  begin
    -- set @colSql=@colSql+ 'distId,distName' 
    set @sql = @sql + 'distId,distName'
    if @existsLx = 1
    begin
      set @sql = @sql + ','

      if @isHzsOtherLx<>1
      begin
      set @sql = @sql + '''汇总数'' as '
      end
      
      set @sql = @sql + 'lx,distName'

      if @isHzsOtherLx = 1
      begin
      set @sql = @sql + '+lx'
      end
              
	set @sql = @sql + '+''汇总数'' as lxname,(select lxid from lxorder '+' where typeCode='''+@tableType+''' and years='+convert(varchar(4),@years)+' and lx='
 
      if @isHzsOtherLx<>1
        set @sql = @sql + '''汇总数'''
      else
		set @sql = @sql + @tableName + '.lx'
      set @sql = @sql + ') as lxid'
    end
  end
  set @colSql=@colSql+','+@sumColumns+' from ('
  set @sql = @sql  + ',' + @sumColumns + ' from ' + @tableName 
  
  if @lx<>'汇总数'-- ====================================================01
  begin
  set @sql=@sql+' left join '  
  
  if @existsLx = 1
  begin
   --q 2015/07/22 修改in语句  set @sql = @sql + ' and left(distId,' +  convert(varchar(40),@distIdInt) + ')+'
	  
	--  if @parentLx='' set @sql = @sql + 'lx' else set @sql = @sql + '''' + @parentLx + ''''
	 -- set @sql = @sql +' not in (select distId + lx from ' + @tableName
	 --set @sql = @sql +' and not exists (select distId + lx from ' + @tableName
	set @sql=@sql+'(select distId as rdistid,lx as rlx from ' + @tableName
  end
  else
  begin
		--set @sql = @sql + ' and left(distId,' +  convert(varchar(40),@distIdInt) + ') not in (select distId from ' + @tableName
	set @sql=@sql+'(select distId as rdistid from ' + @tableName
  end
     -- =================-2
    set @sql = @sql + ' aa where years=' + convert(varchar(4), @years)+' and distId like case when '''+@distId+'''=''0'' then ''%'' else ''' + @distId + '%'' end' 
       
    if @months<>0 
      set @sql = @sql + ' and months=' + convert(varchar(2), @months)
    if (@existsLx = 1) and (@lx<>'')
      set @sql = @sql + ' and lx=''' + @lx + ''''
      
      set @sql = @sql + ')rr '
      
  --q 2015/07/22 修改in语句 
  
    if @existsLx = 1
    begin
    --q 2015/08/03 修改 
   -- set @sql=@sql+'and aa.distid+aa.lx=left('+@tableName+'.distId,' +  convert(varchar(40),@distIdInt) + ')+'
	--set @sql=@sql+' and aa.distid=left('+@tableName+'.distid,'+CONVERT(varchar(40),@distIdInt)+') and aa.lx='
	set @sql=@sql+' on isnull(len(left('+@tableName+'.distid,'+CONVERT(varchar(40),@distIdInt)+')),0)=isnull(len(rr.rdistid),0) and '
    if @parentLx=''
    begin
    set @sql = @sql + @tableName+'.lx=rr.rlx'
    end
    else set @sql = @sql + ' rr.rlx=''' + @parentLx + ''''
    end  
    else
    begin
		set @sql=@sql+' on isnull(len(left('+@tableName+'.distid,'+CONVERT(varchar(40),@distIdInt)+')),0)=isnull(len(rr.rdistid),0)'
    end
    
  end
  

--=================================================1

  set @sql = @sql + ' where  years=' + convert(varchar(4), @years)+' and distId like case when '''+@distId+'''=''0'' then ''%''  else ''' + @distId + '%'' end '
  if @existsLx = 1
  begin
	if (@isHzsOtherLx=1 or @lx='') and @parentLx=''
		set @sql = @sql + ' and charindex(''汇总数'',lxname)=0'
	else
		set @sql = @sql + ' and (charindex(''汇总数'',lxname)=0 or lx in (select parentLx from lxorder where years=' + 
			convert(varchar(4),@years) + ' and typeCode=''' + @tableType + ''' and parentLx is not null and parentLx<>''''))'
	if @parentLx='' and @isHzsOtherLx=0 and @lx='汇总数'   --只有汇总数才执行，其它不执行
		set @sql = @sql + ' and lx not in (select lx from lxorder where years=' + convert(varchar(4),@years) +
			' and typeCode=''' + @tableType + ''' and parentLx is not null and parentLx<>'''')'
  end
  

  if @lx<>'汇总数'
  begin
    set @sql = @sql + ' and len(distId)='
    if @distIdType = 0 
      set @sql = @sql + convert(varchar(40),@distIdInt)
    else if @distIdType = 1  
    begin
      if @distIdInt<=@maxDistIdInt
		begin
		 if @distIdInt=1
		  begin
		  set @sql = @sql + '(select top 1 LEN(distId) from dist where LEN(distId)>' + CONVERT(varchar(50), 0) + '+1 group by LEN(distId) order by LEN(distId))'
		  
		  end	
		  else
		    set @sql = @sql +'(select top 1 LEN(distId) from dist where LEN(distId)>' + CONVERT(varchar(50), @distIdInt) 
							+ '+1 group by LEN(distId) order by LEN(distId))'			
		end				
      else
        set @sql = @sql + convert(varchar(40),@distIdInt)
    end
    else if ((@distIdType = 2) or (@linkDist = 1)) 
      set @sql = @sql + convert(varchar(40),@maxDistIdInt)
    else if @distIdType = 3 
      set @sql = @sql + convert(varchar(40),@distIdLen)
  end
  else
  begin
    if @linkDist=1
    begin
       if @distId=''
         set @sql = @sql + ' and len(distId)=1'
      else
      begin
       set @sql = @sql + ' and len(distId)='
      set @sql = @sql + convert(varchar(40),len(@distId))
      end
    end
  end

  if (@lx<>'') and (not @lx is null) and (@lx<>'汇总数') and (@existsLx = 1)
    set @sql = @sql + ' and lx=''' + @lx + ''''

  if @months<>0 
    set @sql = @sql + ' and months=' + convert(varchar(2), @months)

  -----新数据确保未封存 ======================================02
  if @lx<>'汇总数'
  begin
 --   if @existsLx = 1
 --   begin
 --  --q 2015/07/22 修改in语句  set @sql = @sql + ' and left(distId,' +  convert(varchar(40),@distIdInt) + ')+'
	  
	----  if @parentLx='' set @sql = @sql + 'lx' else set @sql = @sql + '''' + @parentLx + ''''
	-- -- set @sql = @sql +' not in (select distId + lx from ' + @tableName
	-- set @sql = @sql +' and not exists (select distId + lx from ' + @tableName
 --   end
 --   else
 --     set @sql = @sql + ' and left(distId,' +  convert(varchar(40),@distIdInt) + ') not in (select distId from ' + @tableName
      
     -- =================-2
    --set @sql = @sql + ' aa where years=' + convert(varchar(4), @years) + ' and distId like case when '''+@distId+'''=''0'' then ''%'' else ''' + @distId + '%'' end' 
    
    
    
    --if @months<>0 
    --  set @sql = @sql + ' and months=' + convert(varchar(2), @months)
 --   if (@existsLx = 1) and (@lx<>'')
 --     set @sql = @sql + ' and lx=''' + @lx + ''''
 -- --q 2015/07/22 修改in语句 
 --   if @existsLx = 1
 --   begin
 --   --q 2015/08/03 修改 
 --  -- set @sql=@sql+'and aa.distid+aa.lx=left('+@tableName+'.distId,' +  convert(varchar(40),@distIdInt) + ')+'
	--set @sql=@sql+' and aa.distid=left('+@tableName+'.distid,'+CONVERT(varchar(40),@distIdInt)+') and aa.lx='
 --   if @parentLx='' set @sql = @sql + @tableName+'.lx' else set @sql = @sql + '''' + @parentLx + ''''
    --end  
      
    --set @sql = @sql + ')'
   -- =========================================================02
    if @existsLx=1 and @lx='' and @parentLx='' --基础模式
		set @sql = @sql + ' and lx not in (select lx from lxorder where years=' + convert(varchar(4),@years) + 
			' and typecode=''' + @tableType + ''' and not (parentLx is null or parentLx=''''))'
	
    if @existsLx=1 and @lx='' and @parentLx<>'' --村级汇总数
    begin
		set @sql = @sql + ' and lx in (select lx from lxorder where years=' + convert(varchar(4),@years) + 
			' and typecode=''' + @tableType + ''' and parentlx=''' + @parentlx + ''' union ' +
			'select ''' + @parentLx + ''' lx where not exists(select id from ' + @tableName + 
			' where years=' + convert(varchar(4),@years)
		if @months<>0
			set @sql = @sql + ' and months=' + convert(varchar(4),@months)
		set @sql = @sql + ' and distId like   case when '''+@distId+'''=''0'' then ''%'' else ''' + @distId + '%'' end 
		 and len(distId)='
		if @distIdType = 0 --地区长度
			set @sql = @sql + convert(varchar(40),@distIdInt)
		else if @distIdType = 1  
		begin
			if @distIdInt<@maxDistIdInt
				set @sql = @sql + --convert(varchar(40),@distIdInt + 3)
					'(select top 1 LEN(distId) from dist where LEN(distId)>' + CONVERT(varchar(50), @distIdInt) + '+1 group by LEN(distId) order by LEN(distId))'
			else
				set @sql = @sql + convert(varchar(40),@distIdInt)
		end
		else if ((@distIdType = 2) or (@linkDist = 1)) 
			set @sql = @sql + convert(varchar(40),@maxDistIdInt)
		else if @distIdType = 3 
			set @sql = @sql + convert(varchar(40),@distIdLen)
			
		set @sql = @sql + ' and lx in (select lx from lxorder where years=' + convert(varchar(4),@years) + 
			' and typecode=''' + @tableType + ''' and parentLx=''' + @parentLx + '''))'
		set @sql = @sql + ')'
	end
    
    if @distIdInt=1
    begin
		set @sql = @sql +' and rr.rdistid is null '
		set @sql = @sql + ' group by years,distid'
		if @months<>0 
		begin
		 
		set @sql = @sql + ',months '
		end
		if @existsLx = 1 and @parentLx = ''
		 begin
		 set @sql = @sql + ',lx'
		 end
    end                                                                                                                                                                  else
		begin
		   set @sql = @sql + ' group by left(distId,' + convert(varchar(40),@distIdInt) + ')'
		if @existsLx = 1 and @parentLx = ''
		  set @sql = @sql + ',lx'
		end
  end
 
 
 
 --==================================================4
  else--==========================================04
  begin
    if @isHzsOtherLx<>1
      set @sql = @sql + ' and distId' + '+''汇总数'' not in (select distId + ''汇总数'''
    else --q 修改 set @sql = @sql + ' and distId+distname+lx+''汇总数'' not in (select distId + lxname'
       set @sql = @sql + ' and  not exists (select distId + lxname'
    
    set @sql = @sql + ' from ' + @tableName + ' aa where years=' + convert(varchar(4), @years)
    if @months<>0 
      set @sql = @sql + ' and months=' + convert(varchar(2), @months)
    set @sql = @sql + ' and distId like case when '''+@distId+'''=''0'' then  ''%''  else ''' + @distId + '%'' end 
     and charindex(''汇总数'',lxname)<>0'
    if @existsLx = 1
    begin
      if @isHzsOtherLx<>1
        set @sql = @sql + ' and lx=''' + @lx + ''''
      else
        set @sql = @sql + ' and lx=' + @tableName + '.lx and distid='+@tableName+'.distid'
    end
    set @sql = @sql + ')'
    if @isHzsOtherLx=1
    begin
      set @sql = @sql + ' and (select count(*) from ' + @tableName + ' bb where bb.years=' + convert(varchar(50),@years)
      
      if @months<>0 
        set @sql = @sql + ' and bb.months=' + convert(varchar(2), @months)
      set @sql = @sql + ' and bb.lx=' + @tableName + '.lx and bb.distid=' + @tableName + '.distid)>1'
    end
    
    
    if @isHzsOtherLx=1  --只取非有父类型的
		set @sql = @sql + ' and lx not in (select lx from lxorder where not (parentLx is null or parentLx=''''))'
    set @sql = @sql + ' group by years,distId,distName'
    if @isHzsOtherLx=1
      set @sql = @sql + ',lx'
  end

--======================================================04
  
  if @distIdInt=1
  begin
  set @sql=@insertSql+@colSql+@sql+')r group by years,distid,distname'
  if @months<>0 
	 set @sql=@sql+',months'
  if @existsLx = 1 and @parentLx = ''
	set @sql=@sql+',lx,lxname,lxid'
  end
  
  else
  set @sql=@insertSql+@sql
  -- print '江'+@sql
  exec(@sql)
     
end


go

