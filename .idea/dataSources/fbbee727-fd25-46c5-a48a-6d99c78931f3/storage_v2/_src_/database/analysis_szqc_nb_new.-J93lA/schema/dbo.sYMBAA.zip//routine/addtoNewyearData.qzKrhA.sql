



CREATE procedure [dbo].[addtoNewyearData](
@tabletype varchar(50),
@years int
)
as
begin
  declare @typeCode varchar(100),@columns varchar(1000),@modifycolumns varchar(1000),@sql varchar(4000)
--set @years=year(GETDATE())
set @typeCode=''
set @columns=''
set @modifycolumns=''
set @sql=''

--select * from tableType where visib
declare tabtype cursor for  select tabletype from tableType where visible=1  and tabletype=@tabletype

open tabtype
fetch next from tabtype into @typeCode
while @@FETCH_STATUS=0
begin
--追加filelist数据
if not exists(select * from fileList where years=convert(varchar(50),@years) and  typeCode=@typeCode ) 
 begin
 execute findtabcolumns 'fileList','years','m',@columns output,@modifycolumns output
 set @sql='insert into fileList(years,'+@columns+')
		select '+convert(varchar(50),@years)+' years,'+@modifycolumns+' from filelist m
		where m.typeCode='''+@typeCode+''' and m.years='+convert(varchar(50),@years)+'-1 and isnull(m.tablename,'''')<>'''''
exec (@sql) 
 end
 
--追加fileitem数据
if not exists(select m.id from fileitem m  inner join filelist f 
				on m.years=f.years and m.tablename=f.tableName and  typeCode=@typeCode and tableType='基本表' and f.tablename<>''
			 where m.years=convert(varchar(50),@years)) 
 begin
 execute findtabcolumns 'fileItem','years','m',@columns output,@modifycolumns output
 set @sql='insert into fileItem(years,'+@columns+')
 select '+convert(varchar(50),@years)+'  years,'+@modifycolumns+' from fileitem m inner join filelist f on m.years=f.years and m.tablename=f.tableName and  f.typeCode='''+@typeCode+''' 
  and tableType=''基本表'' and f.tablename<>''''  
 where  m.years='+convert(varchar(50),@years)+'-1 and m.tablename<>'''' '
 exec (@sql) 
 end
 
  --追加fileitem 分析数据
if not exists(select m.id from fileitem m  inner join filelist f 
							on m.years=f.years and m.tablename='ans_'+convert(varchar(10),f.ansNo) and  typeCode=@typeCode  and tableType='分析表' and ISNULL(f.tablename,'')<>''
				 where m.years=convert(varchar(50),@years)) 
 begin
 execute findtabcolumns 'fileItem','years','m',@columns output,@modifycolumns output
  set @sql='insert into fileItem(years,'+@columns+')
  select '+convert(varchar(50),@years)+'  years,'+@modifycolumns+' from fileitem m inner join filelist f
  on m.years=f.years and m.tablename=''ans_''+convert(varchar(10),f.ansNo) and f.typeCode='''+@typeCode+''' and tableType=''分析表''
	  and ISNULL(f.tablename,'''')<>''''  and ISNULL(f.ansNo,0)<>0
 where  m.years='+convert(varchar(50),@years)+'-1' 
 exec (@sql) 
 end
 
  
 --追加fileItemLink 数据
if not exists(select k.id from fileItemLink k inner join filelist f on k.years=f.years and k.tableName=f.tableName and f.typeCode=@typeCode and f.tablename<>''
 where k.years=convert(varchar(50),@years) )					
begin
execute findtabcolumns 'fileItemLink','years','k',@columns output,@modifycolumns output
set @sql='insert into fileItemLink(years,'+@columns+')select '+convert(varchar(50),@years)+' years,'
+@modifycolumns+' from fileItemLink k inner join filelist f on k.years=f.years and k.tableName=f.tableName and f.typeCode='''+@typeCode+'''
 and f.tabletype=''基本表'' and f.tablename<>''''
 where k.years='+convert(varchar(50),@years)+'-1' 
exec (@sql) 
end

--追加fileItemLinkex 数据
 if not exists(select k.id from fileItemLinkex  k inner join filelist f on k.years=f.years and k.tableName=f.tableName and f.typeCode=@typeCode and f.tablename<>'' where k.years=convert(varchar(50),@years)) 
begin
execute findtabcolumns 'fileItemLinkex','years','k',@columns output,@modifycolumns output
set @sql='insert into fileItemLinkex(years,'+@columns+')
select '+convert(varchar(50),@years)+' years,'+@modifycolumns+' from fileItemLinkex k inner join filelist f 
on k.years=f.years and k.tableName=f.tableName and f.typeCode='''+@typeCode+'''  and f.tabletype=''基本表'' and isnull(f.tablename,'''')<>'''' 
where k.years='+convert(varchar(50),@years)+'-1' 
exec(@sql)
 end
 
 --追加fileItemLinkExEx 锁定类型后，村，镇录入权限的控制表
 if not exists(select k.id from fileItemLinkExEx  k inner join filelist f on k.years=f.years and k.tableName=f.tableName and f.typeCode=@typeCode 
						and ISNULL(f.tablename,'')<>'' where k.years=convert(varchar(50),@years)) 
begin
execute findtabcolumns 'fileItemLinkExEx','years','k',@columns output,@modifycolumns output
set @sql=' insert into fileItemLinkExEx(years, '+@columns+')
select '+convert(varchar(50),@years)+' years,'+@modifycolumns+' from fileItemLinkExEx k inner join filelist f 
 on k.years=f.years and k.tableName=f.tableName and f.typeCode='''+@typeCode+'''  and f.tabletype=''基本表'' and  ISNULL(f.tablename,'''')<>''''
  where k.years='+convert(varchar(50),@years)+'-1'
  exec (@sql)
 end
 
 --追加field_fomula 数据
 if not exists( select k.id from field_fomula k inner join filelist f 
					 on k.years=f.years and k.tableName=f.tableName and f.typeCode=@typeCode  and  ISNULL(f.tablename,'')<>'' 
				where  k.years=convert(varchar(50),@years))
begin
execute findtabcolumns 'field_fomula','years','k',@columns output,@modifycolumns output
set @sql='insert into field_fomula(years,'+@columns+') 
select '+convert(varchar(50),@years)+' years,'+@modifycolumns+' from field_fomula k inner join filelist f 
				 on k.years=f.years and k.tableName=f.tableName and f.typeCode='''+@typeCode+'''  and f.tabletype=''基本表'' and  ISNULL(f.tablename,'''')<>''''
where  k.years='+convert(varchar(50),@years)+'-1' 
exec (@sql)
  end
 
  --追加lxorder 数据
  if not exists(select id from lxorder where   typeCode=@typeCode and years=convert(varchar(50),@years))
 begin
 execute findtabcolumns 'lxorder','years','',@columns output,@modifycolumns output
 set @sql='insert into lxorder(years,'+@columns+')select '+convert(varchar(50),@years)+' as  years,'+@columns+'
  from lxorder where typeCode='''+@typeCode+''' and years='+convert(varchar(50),@years)+'-1'
 exec (@sql) 
 end   
    
 --追加middle_lxorder 数据 
   if not exists(select id from middle_lxorder where   typeCode=@typeCode and years=convert(varchar(50),@years))
 begin
  execute findtabcolumns 'middle_lxorder','years','',@columns output,@modifycolumns output
  set @sql=' insert into middle_lxorder(years,'+@columns+')
  select '+convert(varchar(50),@years)+' as years, '+@columns+' from middle_lxorder where typeCode='''+@typeCode+''' and years='+convert(varchar(50),@years)+'-1'
 exec (@sql) 
  end
  
   ---追加分析表公式 Ans_table
  if not exists( select sno  from Ans_table a inner join filelist f 
									on a.years=f.years and a.repno=f.ansNo and f.typeCode=@typeCode and tableType='分析表'  and ISNULL(f.ansNo,0)<>0  
				where a.years=convert(varchar(50),@years) and isnull(months,0)=0)
  begin
  execute findtabcolumns 'Ans_table','years','a',@columns output,@modifycolumns output
  set @sql='insert into Ans_table( years,'+@columns+')
   select '+convert(varchar(50),@years)+' as years,'+@modifycolumns+' from Ans_table a inner join filelist f on a.years=f.years and a.repno=f.ansNo 
   and f.typeCode='''+@typeCode+''' 
   and tableType=''分析表''  and ISNULL(f.ansNo,0)<>0  
    where a.years='+convert(varchar(50),@years)+'-1 and isnull(months,0)=0'
 exec (@sql) 
  end
  
--追加平衡公式表
if not exists(select * from _sRuleInner n join filelist f on n.years=f.years and n.tableName=f.tableName and f.tableType='基本表' and f.typeCode=@typeCode where n.years=convert(varchar(50),@years) )
begin
insert into _sRuleInner(years, tableName, fieldName, express, detail, opt, orderId, useFlag, readOnly, evalFlag )
select convert(varchar(50),@years) as years, n.tableName, fieldName, express, detail, opt, n.orderId, n.useFlag, readOnly, evalFlag 
from dbo._sRuleInner n join filelist f 
on n.years=f.years and n.tableName=f.tableName and f.tableType='基本表' and f.typeCode=@typeCode 
where n.years=convert(varchar(50),@years)-1
end

--追加表间公式表
if not exists(select n.id from _sRuleOuter n join filelist f on n.years=f.years and n.tableDec=f.tableName and f.tableType='基本表' and f.typeCode=@typeCode 
				where n.years=convert(varchar(50),@years) )
begin
insert into dbo._sRuleOuter(years, tableDec, decExpress, sourceExpress, Detail, exCond, opt, orderId, evalFlag, sourceCondExpress, tableflag, lx)
select  convert(varchar(50),@years) as years, tableDec, decExpress, sourceExpress, Detail, exCond, opt, n.orderId, evalFlag, sourceCondExpress, tableflag, lx
from dbo._sRuleOuter n join filelist f 
on n.years=f.years and n.tableDec=f.tableName and f.tableType='基本表' and f.typeCode=@typeCode
where n.years=convert(varchar(50),@years)-1
end

  
  
  
fetch next from tabtype into @typeCode
end
close tabtype
deallocate tabtype

--追加地区
if  not exists (select id from dist where years=@years )
begin
 execute findtabcolumns 'dist','years','d',@columns output,@modifycolumns output
set @sql='insert into  dist(years,'+@columns+')
		select '+CONVERT(varchar(10),@years)+' as years,'+@modifycolumns+' from dist d 
		left join (select distid from dist  where years='+convert(varchar(50),@years)+' and ISNULL(distId,'''')<>'''' and ISNULL(distName,'''')<>'''')dd
		on d.distId=dd.distId
		where d.years='+convert(varchar(50),@years)+'-1 and ISNULL(d.distId,'''')<>'''' and ISNULL(d.distName,'''')<>'''' and dd.distId is null'
		exec(@sql)
end



end

go

