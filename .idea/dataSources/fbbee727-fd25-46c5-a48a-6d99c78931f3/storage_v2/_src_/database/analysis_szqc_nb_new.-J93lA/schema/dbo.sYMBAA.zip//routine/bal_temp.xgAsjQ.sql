

CREATE   PROCEDURE [dbo].[bal_temp](
       @years int,
       @months int,
       @acc_code varchar(100),
       @YSYF int,
       @distid varchar(100),
       @acc_modal int,
       @bjaccount varchar(50)
       )AS
       declare @sql varchar(6000)
       declare @errorSum int
       declare @repno int
       begin
       set @errorSum=0
       set @repno=1
      begin Transaction
      set @sql='insert into bal_tmp( zth,acc_code,years, YSYF,distid, Bal_years_begin, Bal_moths_end, Debit_years, Credit_years
      ,Bal_years_3,Debit_years_3,Credit_years_3,Credit_years_2,Debit_years_2,Amount_tot, Y1, Y3, B1, B5) 
      select b.acc_set,acc_code,'+CONVERT(varchar(50),@years)+' as years,'+CONVERT(varchar(10),@YSYF)+' as YSYF,linkDistId as distid,sum(bal_year_begin)a1 ,sum(bal_month_end)a2,sum(debit_year)a3,sum(credit_year)a4,
      0 as Bal_years_3 ,0 as Debit_years_3,0 as Credit_years_3,0 as Credit_years_2,0 as Debit_years_2,
      0 as Amount_tot,0 as Y1,0 as Y3,0 as B1,0 as B5 from '+@bjaccount+'.dbo.balance b ,(select acc_set,linkDistId from '+@bjaccount+'.dbo.acc_set where acc_modal in('+convert(varchar(50),@acc_modal)+') and linkDistId like '''+@distid+'%''  )a
      where acc_code like '''+@acc_code+'%'' and years='+convert(varchar(50),@years)+' and months='+convert(varchar(50),@months)+' and b.acc_set=a.acc_set group by b.acc_set,acc_code,linkDistId'
      exec(@sql)
      --print @sql
      
     set @sql='update bal_tmp set Bal_years_3=b.Bal_years_3,Debit_years_3=b.Debit_years_3,Credit_years_3=b.Credit_years_3
      from bal_tmp p,(select b.acc_set ,acc_code,sum(bal_year_begin) as Bal_years_3,sum(debit_year) as Debit_years_3,sum(credit_year) as Credit_years_3
      from '+@bjaccount+'.dbo.balance b ,(select acc_set,linkDistId from '+@bjaccount+'.dbo.acc_set where acc_modal in('+convert(varchar(50),@acc_modal)+') and linkDistId like '''+@distid+'%''  )a
        where acc_code like '''+@acc_code+'%'' and years='+convert(varchar(50),@years)+'-2 and months='+convert(varchar(50),@months)+' and b.acc_set=a.acc_set group by b.acc_set,acc_code)b where p.zth=b.acc_set and p.acc_code=b.acc_code'
       exec(@sql)
        --print @sql
       set @errorSum=@errorSum+@@ERROR
               
       set @sql='update bal_tmp set Debit_years_2=b.debit_years_2,Credit_years_2=b.credit_years_2 from bal_tmp p,(select b.acc_set,acc_code,SUM(debit_year) as debit_years_2,SUM(credit_year) as credit_years_2
      from '+@bjaccount+'.dbo.balance b ,(select acc_set,linkDistId from '+@bjaccount+'.dbo.acc_set where acc_modal in('+convert(varchar(50),@acc_modal)+') and linkDistId like '''+@distid+'%''  )a
        where acc_code like '''+@acc_code+'%'' and years='+convert(varchar(50),@years)+'-1 and months='+convert(varchar(50),@months)+' and b.acc_set=a.acc_set group by b.acc_set,acc_code)b  where p.zth=b.acc_set and p.acc_code=b.acc_code'
      exec(@sql)
       --print @sql
      set @errorSum=@errorSum+@@ERROR  
      
      set @sql='update bal_tmp set Amount_tot=b.c3 from 
      (select a.acc_set,c1,sum(convert(money,c3))as c3 from(select t.acc_set,years,months,c1,c3  from '+@bjaccount+'.dbo.rep_table t,
       (select acc_set,linkDistId from '+@bjaccount+'.dbo.acc_set where acc_modal in('+convert(varchar(50),@acc_modal)+') and linkDistId like '''+@distid+'%''  )a
     where  years='+CONVERT(varchar(50),@years)+' and months='+CONVERT(varchar(50),@months)+' and repno='+convert(varchar(50),@repno)+' and Ltrim(Rtrim(t.C1)) in(''资产总计'',''资产合计'')   and t.acc_set=a.acc_set 
    union all
    select t.acc_set,years,months,c4,c6  from '+@bjaccount+'.dbo.rep_table t,
    (select acc_set,linkDistId from '+@bjaccount+'.dbo.acc_set where acc_modal in('+convert(varchar(50),@acc_modal)+') and linkDistId like '''+@distid+'%''  )a 
    where  years='+CONVERT(varchar(50),@years)+' and months='+convert(varchar(50),@months)+'  and repno='+convert(varchar(50),@repno)+' and Ltrim(Rtrim(t.C1)) in(''资产总计'',''资产合计'')   and t.acc_set=a.acc_set
     
    )a group by a.acc_set,c1)b
    where b.C1 is not null and bal_tmp.zth=b.acc_set'
   exec(@sql)
    -- print @sql
       set @errorSum=@errorSum+@@ERROR
      
      /* 
       set @sql='update bal_tmp set Y1=b.y1  from bal_tmp p,( select acc_set,acc_code,sum(bal_year_begin-credit_year) as y1,years
      from '+@bjaccount+'.dbo.balance   where acc_code like '''+@acc_code+'%'' and years='+convert(varchar(50),@years)+'
    and months='+convert(varchar(50),@months)+'  and bal_year_begin>credit_year group by acc_set,acc_code,years )b where p.zth=b.acc_set and p.acc_code=b.acc_code '
     */
     if @YSYF=0
     begin
     set @sql='update bal_tmp set Y1=b.y1  from  (select years,zth,acc_code,
						case   when  sum(Bal_years_begin)>=sum(Credit_years) then 1 else  0 end y1
					from bal_tmp where YSYF=0 and years='+CONVERT(varchar(50),@years)+'  and Bal_years_begin<>0 and Credit_years<>0
					 group by years,zth,acc_code)b
				where bal_tmp.years=b.years and YSYF=0 and bal_tmp.zth=b.zth and bal_tmp.acc_code=b.acc_code '
	 end
	  if @YSYF=1
     begin
     set @sql='update bal_tmp set Y1=b.y1  from  (select years,zth,acc_code,
						case   when  sum(Bal_years_begin)>=sum(debit_years) then 1 else  0 end y1
					from bal_tmp where YSYF=1 and years='+CONVERT(varchar(50),@years)+' and Bal_years_begin<>0 and debit_years<>0
					 group by years,zth,acc_code)b
				where bal_tmp.years=b.years and YSYF=1 and bal_tmp.zth=b.zth and bal_tmp.acc_code=b.acc_code '
	 end
      exec(@sql)
        --print @sql
      set @errorSum=@errorSum+@@ERROR
      
     /* set @sql=' update bal_tmp set Y3= b.y3 from bal_tmp p,( select zth,acc_code, sum(Bal_years_begin-(Dedit_years+Debit_years_2+Debit_years_3)) as y3 from bal_tmp
        where Bal_years_begin>(Dedit_years+Debit_years_2+Debit_years_3) and acc_code like '''+@acc_code+'%''  group by zth,acc_code  )b where p.zth=b.zth and p.acc_code=b.acc_code'
     */
     if @YSYF=0
     begin
		set @sql ='update bal_tmp set Y3=b.y3  from  (select years,zth,acc_code,
								case   when  sum(Bal_years_begin)>=sum(Credit_years+Credit_years_2+Credit_years_3) then 1 else  0 end y3
								from bal_tmp where YSYF=0 and years='+CONVERT(varchar(50),@years)+'  and Bal_years_begin<>0 and (Credit_years+Credit_years_2+Credit_years_3)<>0
								group by years,zth,acc_code)b
					 where    YSYF=0  and bal_tmp.years=b.years and bal_tmp.zth=b.zth and bal_tmp.acc_code=b.acc_code '
     end 
      if @YSYF=1
     begin
		set @sql ='update bal_tmp set Y3=b.y3  from  (select years,zth,acc_code,
								case   when  sum(Bal_years_begin)>=sum(debit_years+debit_years_2+debit_years_3) then 1 else  0 end y3
								from bal_tmp where YSYF=1 and years='+CONVERT(varchar(50),@years)+' and Bal_years_begin<>0 and (debit_years+debit_years_2+debit_years_3)<>0 
								group by years,zth,acc_code)b
					 where  YSYF=1  and  bal_tmp.years=b.years and bal_tmp.zth=b.zth and bal_tmp.acc_code=b.acc_code '
     end 
     exec(@sql)
      --print @sql
      set @errorSum=@errorSum+@@ERROR
      
      /*
      set @sql='  update bal_tmp set B1=b.a
  from bal_tmp p,(select zth,acc_code, case when isnull(Amount_tot,0)=0 then 0
                when Bal_moths_end*100/isnull(Amount_tot,0)>=1 then 1 
                end as a from bal_tmp where acc_code like '''+@acc_code+'%'')b where p.zth=b.zth and p.acc_code=b.acc_code'
                */
                
       set @sql='update bal_tmp set B1=a.B1 from (select years,zth,acc_code,1 as B1 
									from  bal_tmp  where years='+CONVERT(varchar(50),@years)+' and  Bal_moths_end*100/Amount_tot>=1 and Amount_tot<>0
									group by years,zth,acc_code)a
					where  bal_tmp.years=a.years and  bal_tmp.zth=a.zth and bal_tmp.acc_code=a.acc_code '         
      exec(@sql)
       --print @sql
      set @errorSum=@errorSum+@@ERROR
      
         /*set @sql='update bal_tmp set B5=b.a
  from bal_tmp p,(select zth,acc_code, case when isnull(Amount_tot,0)=0 then 0
                when Bal_moths_end*100/isnull(Amount_tot,0)>=5 then 1 
                end as a from bal_tmp where acc_code like '''+@acc_code+'%'')b where p.zth=b.zth and p.acc_code=b.acc_code'
                */
      set @sql='update bal_tmp set B5=a.B5 from (select years,zth,acc_code,1 as B5 
									from  bal_tmp  where years='+CONVERT(varchar(50),@years)+' and  Bal_moths_end*100/Amount_tot>=5 and Amount_tot<>0
									group by years,zth,acc_code)a
					where  bal_tmp.years=a.years and  bal_tmp.zth=a.zth and bal_tmp.acc_code=a.acc_code '        
      exec(@sql)
       --print @sql
      set @errorSum=@errorSum+@@ERROR
      
      if @errorSum<>0
      rollback transaction
      else
      commit transaction
     -- select @errorSum
            end
go

