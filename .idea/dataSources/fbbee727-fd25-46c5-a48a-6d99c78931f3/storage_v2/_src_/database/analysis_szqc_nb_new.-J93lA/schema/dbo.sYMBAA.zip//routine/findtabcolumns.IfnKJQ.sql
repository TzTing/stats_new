

create procedure [dbo].[findtabcolumns] 
@tablename varchar(20),
@excludecolumn varchar(100),
@tabalias varchar(10),
@yscolumn varchar(1000) output,
@modifycolumn varchar(1000) output
as 
begin
 declare   @columns varchar(2000),@mcolumns varchar(2000),@columnName varchar(50),@point varchar(5)
 set @columns=''
 set @mcolumns=''
 set @point=@tabalias+'.'
 if @tabalias=''
 set @point=''
 declare coms cursor for 
 select c.name from syscolumns c inner join sysobjects o 
 on c.id=o.id and o.xtype='U'
 inner join systypes t
 on c.xtype=t.xusertype 
 left join sys.columns sm
 on OBJECT_NAME(OBJECT_ID) =o.name and sm.name=c.name and is_identity=1
 where o.name=@tablename 
 and c.name not in(select short_str from dbo.F_SQLSERVER_SPLIT(@excludecolumn,','))
 and sm.name is null 
 open coms 
 fetch next from coms into @columnName
 while @@FETCH_STATUS=0
 begin
 if @columns<>''
 set @columns=@columns+','
 if @mcolumns<>''
 set @mcolumns=@mcolumns+','
 
 set @columns=@columns+@columnName
 set @mcolumns=@mcolumns+@point+@columnName
 
 fetch next from coms into @columnName
 end
 close coms
 deallocate coms 
 set @yscolumn=@columns
 set @modifycolumn=@mcolumns
 end
go

