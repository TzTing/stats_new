

CREATE FUNCTION [dbo].[fn_njtj001]
( 
	@years int,
	@distlen int	--地区分组长度 省0 市2 区4 镇6 村9
	
) 
RETURNS table 
AS 
RETURN (

select (zs-c23) wlr, (zs_1-c23_1) wlr_1, (zs_2-c23_2) wlr_2, b.distname,a.* from (
select years, case when left(distid,@distlen)='' then '0' else left(distid,@distlen) end distid, SUM(zs) zs, SUM(zs_1) zs_1, SUM(zs_2) zs_2, round(SUM(c23),0) c23, round(SUM(c23_1),0) c23_1, round(SUM(c23_2),0) c23_2, round(SUM(c24),0) c24, round(SUM(c24_1),0) c24_1, round(SUM(c24_2),0) c24_2, round(SUM(c25),0) c25, round(SUM(c25_1),0) c25_1, round(SUM(c25_2),0) c25_2, round(SUM(c26),0) c26, round(SUM(c26_1),0) c26_1, round(SUM(c26_2),0) c26_2, round(SUM(c27),0) c27, round(SUM(c27_1),0) c27_1, round(SUM(c27_2),0) c27_2, round(SUM(c28),0) c28, round(SUM(c28_1),0) c28_1, round(SUM(c28_2),0) c28_2, round(SUM(c29),0) c29, round(SUM(c29_1),0) c29_1, round(SUM(c29_2),0) c29_2, round(SUM(c30),0) c30, round(SUM(c30_1),0) c30_1, round(SUM(c30_2),0) c30_2, round(SUM(c31),0) c31, round(SUM(c31_1),0) c31_1, round(SUM(c31_2),0) c31_2, round(SUM(c32),0) c32, round(SUM(c32_1),0) c32_1, round(SUM(c32_2),0) c32_2 from (
----------------------------------------------------------------
select distinct b.years,b.distid,b.distname,b.cjlx,
--总数
1 zs,(case when isnull(b.cjlx,1)=1 then 1 else 0 end) zs_1,(case when isnull(b.cjlx,0)=2 then 1 else 0 end) zs_2,
--汇入本表村数
(case when isnull(a.distid,'')<>'' then 1 else 0 end) c23,(case when isnull(b.cjlx,1)=1 and isnull(a.distid,'')<>'' then 1 else 0 end) c23_1,(case when isnull(b.cjlx,0)=2 and isnull(a.distid,'')<>'' then 1 else 0 end) c23_2,
--无收益村居(<=0万)
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)<=0 then 1 else 0 end) c24,(case when isnull(b.cjlx,1)=1 and isnull(a.distid,'')<>'' and ISNULL(c13,0)<=0 then 1 else 0 end) c24_1,(case when isnull(b.cjlx,0)=2 and isnull(a.distid,'')<>'' and ISNULL(c13,0)<=0 then 1 else 0 end) c24_2,
--有收益村居(>0万)
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)>0 then 1 else 0 end) c25,(case when isnull(b.cjlx,1)=1 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>0 then 1 else 0 end) c25_1,(case when isnull(b.cjlx,0)=2 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>0 then 1 else 0 end) c25_2,
--0-5万
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)>0 and ISNULL(c13,0)<5 then 1 else 0 end) c26,(case when isnull(b.cjlx,1)=1 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>0 and ISNULL(c13,0)<5 then 1 else 0 end) c26_1,(case when isnull(b.cjlx,0)=2 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>0 and ISNULL(c13,0)<5 then 1 else 0 end) c26_2,
--5-10万
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)>=5 and ISNULL(c13,0)<10 then 1 else 0 end) c27,(case when isnull(b.cjlx,1)=1 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>=5 and ISNULL(c13,0)<10 then 1 else 0 end) c27_1,(case when isnull(b.cjlx,0)=2 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>=5 and ISNULL(c13,0)<10 then 1 else 0 end) c27_2,
--10-50万
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)>=10 and ISNULL(c13,0)<50 then 1 else 0 end) c28,(case when isnull(b.cjlx,1)=1 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>=10 and ISNULL(c13,0)<50 then 1 else 0 end) c28_1,(case when isnull(b.cjlx,0)=2 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>=10 and ISNULL(c13,0)<50 then 1 else 0 end) c28_2,
--50-100万
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)>=50 and ISNULL(c13,0)<100 then 1 else 0 end) c29,(case when isnull(b.cjlx,1)=1 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>=50 and ISNULL(c13,0)<100 then 1 else 0 end) c29_1,(case when isnull(b.cjlx,0)=2 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>=50 and ISNULL(c13,0)<100 then 1 else 0 end) c29_2,
--100-1000万
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)>=100 and ISNULL(c13,0)<1000 then 1 else 0 end) c30,(case when isnull(b.cjlx,1)=1 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>=100 and ISNULL(c13,0)<1000 then 1 else 0 end) c30_1,(case when isnull(b.cjlx,0)=2 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>=100 and ISNULL(c13,0)<1000 then 1 else 0 end) c30_2,
--1000-10000万
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)>=1000 and ISNULL(c13,0)<10000 then 1 else 0 end) c31,(case when isnull(b.cjlx,1)=1 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>=1000 and ISNULL(c13,0)<10000 then 1 else 0 end) c31_1,(case when isnull(b.cjlx,0)=2 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>=1000 and ISNULL(c13,0)<10000 then 1 else 0 end) c31_2,
--10000万以上
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)>=10000 then 1 else 0 end) c32,(case when isnull(b.cjlx,1)=1 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>=10000 then 1 else 0 end) c32_1,(case when isnull(b.cjlx,0)=2 and isnull(a.distid,'')<>'' and ISNULL(c13,0)>=10000 then 1 else 0 end) c32_2

from (select * from rep905 where years=@years and lx='汇总数' and LEN(distid)=9) a right join dist b on a.years=b.years and a.distid=b.distid where b.years=@years and LEN(b.distid)=9
----------------------------------------------------------------
)a group by years,left(distid,@distlen)
)a join dist b on a.years=b.years and a.distid=b.distid

)


go

