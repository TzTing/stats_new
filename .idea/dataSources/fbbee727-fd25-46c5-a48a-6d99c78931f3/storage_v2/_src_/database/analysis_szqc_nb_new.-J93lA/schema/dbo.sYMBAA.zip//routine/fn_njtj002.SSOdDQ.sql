CREATE FUNCTION [dbo].[fn_njtj002]
( 
	@years int,
	@distlen int,	--地区分组长度 省0 市2 区4 镇6 村9
	@tableType varchar(50)
	
) 
RETURNS table 
AS 
RETURN (

select a.distid, a.distname, isnull(b.ybzs,0) ybzs, isnull(c.sbzs,0) sbzs, 
(case when ISNULL(c.sbzs,0)=0 then 0 else (CAST(round(c.sbzs*1.00/b.ybzs*100,2) as numeric(14,2))) end) as sbl1, 
isnull(d.ybcs,0) ybcs, isnull(e.sbcs,0) sbcs, 
(case when ISNULL(e.sbcs,0)=0 then 0 else (CAST(round(e.sbcs*1.00/d.ybcs*100,2) as numeric(14,2))) end) as sbl2,
isnull(f.ybxs,0) ybxs, isnull(g.sbxs,0) sbxs,
(case when ISNULL(g.sbxs,0)=0 then 0 else (CAST(round(g.sbxs*1.00/f.ybxs*100,2) as numeric(14,2))) end) as sbl3 
from (
select * from dist where years=@years and LEN(distid)=(case when @distlen=0 then 1 else @distlen end) and distName<>'调整数'
)a left join (
select (case when LEFT(distid,@distlen)  ='' then '0' else LEFT(distid,@distlen)   end) distid,COUNT(*) ybzs from dist where years=@years and LEN(distid)=6 and distName<>'调整数' group by LEFT(distid,@distlen) 
)b on a.distId=b.distid left join (
select (case when LEFT(distno,@distlen)  ='' then '0' else LEFT(distno,@distlen)   end) distid,COUNT(*) sbzs from uploadBase where years=@years and LEN(distno)=6 and distName<>'调整数' and ISNULL(okflag,0)=1 and tableType=@tableType group by LEFT(distno,@distlen)
)c on a.distId=c.distid left join (
select (case when LEFT(distid,@distlen)  ='' then '0' else LEFT(distid,@distlen)   end) distid,COUNT(*) ybcs from dist where years=@years and LEN(distid)=9 and distName<>'调整数' group by LEFT(distid,@distlen) 
)d on a.distId=d.distid left join (
select (case when LEFT(distno,@distlen)  ='' then '0' else LEFT(distno,@distlen)   end) distid,COUNT(*) sbcs from uploadBase where years=@years and LEN(distno)=9 and distName<>'调整数' and ISNULL(okflag,0)=1 and tableType=@tableType group by LEFT(distno,@distlen)
)e on a.distId=e.distid left join (
select (case when LEFT(distid,@distlen)  ='' then '0' else LEFT(distid,@distlen)   end) distid,COUNT(*) ybxs from dist where years=@years and LEN(distid)=4 group by LEFT(distid,@distlen) 
)f on a.distId=f.distid left join (
select (case when LEFT(distno,@distlen)  ='' then '0' else LEFT(distno,@distlen)   end) distid,COUNT(*) sbxs from uploadBase where years=@years and LEN(distno)=4 and ISNULL(okflag,0)=1 and tableType=@tableType group by LEFT(distno,@distlen)
)g on a.distId=g.distid

)
go

