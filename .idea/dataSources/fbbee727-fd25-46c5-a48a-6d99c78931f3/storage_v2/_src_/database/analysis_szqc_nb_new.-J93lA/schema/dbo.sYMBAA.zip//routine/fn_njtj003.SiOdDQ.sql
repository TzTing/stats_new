CREATE FUNCTION [dbo].[fn_njtj003]
( 
	@years int,
	@distlen int	--地区分组长度 省0 市2 区4 镇6 村9
	
) 
RETURNS table 
AS 
RETURN (

--注意替换清产核资数据库zcjy_szqc

select b.distname, a.* from (
select xh, (case when LEFT(distid,@distlen)='' then '0' else LEFT(distid,@distlen) end) distid, zb, SUM(qc) qc, SUM(nb) nb, SUM(nb)-SUM(qc) ce,
(case when SUM(qc)=0 then 0 else cast(round((SUM(nb)-SUM(qc))*1.0/SUM(qc)*100,2) as numeric(18,2)) end) zf from (

--1
select isnull(a.distno,b.distid) distid,isnull(a.distname,b.distname) distname,1 xh,'汇总乡镇数' zb,(case when isnull(a.distno,'')<>'' then 1 else 0 end) qc,(case when isnull(b.distid,'')<>'' then 1 else 0 end) nb from zcjy_szqc..dist a full outer join (select * from dist where years=@years) b on a.distno=b.distid where (LEN(a.distno)=6 or LEN(b.distid)=6) and (a.distno like '%' or b.distId like '%')
union
--2
select isnull(a.distno,b.distid) distid,isnull(a.distname,b.distname) distname,2 xh,'村数' zb,(case when isnull(a.distno,'')<>'' then 1 else 0 end) qc,(case when isnull(b.distid,'')<>'' then 1 else 0 end) nb from zcjy_szqc..dist a full outer join (select * from dist where years=@years) b on a.distno=b.distid where (LEN(a.distno)=9 or LEN(b.distid)=9) and (a.distno like '%' or b.distId like '%')
--union
----3
--select ztid,ztname,3 xh,'村社两级组织总数' zb,1 qc,0 nb from zcjy_szqc..zt where ztTypeId in(1,3,12, 2,4) and distno like '%'
--union
--select distId,distName,3 xh,'村社两级组织总数' zb,0 qc,2 nb from dist where years=@years and LEN(distid)=9 and distId like '%'
--union
----4
--select ztid,ztname,4 xh,'其中：经联社' zb,1 qc,0 nb from zcjy_szqc..zt where ztTypeId in(1,3,12) and distno like '%'
--union
--select distId,distName,4 xh,'其中：经联社' zb,0 qc,1 nb from dist where years=@years and LEN(distid)=9 and distId like '%'
--union
----5
--select ztid,ztname,5 xh,'      经济社' zb,1 qc,0 nb from zcjy_szqc..zt where ztTypeId in(2,4) and distno like '%'
--union
--select distId,distName,5 xh,'      经济社' zb,0 qc,1 nb from dist where years=@years and LEN(distid)=9 and distId like '%'

)a group by xh,LEFT(distid,@distlen),zb --order by xh,distid
)a join (select * from dist where years=@years and distName<>'调整数')b on a.distid=b.distid

)

go

