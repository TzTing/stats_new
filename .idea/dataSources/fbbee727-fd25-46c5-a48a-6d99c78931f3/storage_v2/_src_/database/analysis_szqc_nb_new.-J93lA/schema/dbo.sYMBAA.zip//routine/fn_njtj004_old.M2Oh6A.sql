
CREATE FUNCTION [dbo].[fn_njtj004_old]
( 
	@years int,
	@distlen int,	--地区分组长度		省0 市2 区4 镇6 村9
	@tj_distlen	int --从哪一级开始统计　市2 区4 镇6 村9
	
) 
RETURNS table 
AS 
RETURN (

--注意替换清产核资数据库analysis_szqc


select b.distname, a.* from (
select xh, (case when LEFT(distid,@distlen)='' then '0' else LEFT(distid,@distlen) end) distid, zb, SUM(qc) qc, SUM(nb) nb, SUM(nb)-SUM(qc) ce,
(case when SUM(qc)=0 then 0 else cast(round((SUM(nb)-SUM(qc))*1.0/SUM(qc)*100,2) as numeric(18,2)) end) zf from (
--------------------------

--集体农用地
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 1 xh, '集体农用地' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,sum(c2) qc from analysis_szqc..rep_szqc_09 where years=2017 and sumflag=( case when @tj_distlen=9 then '否' else sumflag end) and LEN(distid)=@tj_distlen and lx in('经联社','村(居)委会','联社公司','调整数' , '经济社','经济社公司','村(居)小组') group by distid,distname
)a full outer join (
	select distinct distid,distname,c21*10000 nb from rep901 where years=@years and LEN(distid)=@tj_distlen
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--1.耕地
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 2 xh, '   1.耕地' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,sum(c3) qc from analysis_szqc..rep_szqc_09 where years=2017 and sumflag=( case when @tj_distlen=9 then '否' else sumflag end) and LEN(distid)=@tj_distlen and lx in('经联社','村(居)委会','联社公司','调整数' , '经济社','经济社公司','村(居)小组') group by distid,distname
)a full outer join (
	select distinct distid,distname,c22*10000 nb from rep901 where years=@years and LEN(distid)=@tj_distlen
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--其中：归村所有
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 3 xh, '   其中：归村所有' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,sum(c3) qc from analysis_szqc..rep_szqc_09 where years=2017 and sumflag=( case when @tj_distlen=9 then '否' else sumflag end) and LEN(distid)=@tj_distlen and lx in('经联社','村(居)委会','联社公司','调整数') group by distid,distname
)a full outer join (
	select distinct distid,distname,c23*10000 nb from rep901 where years=@years and LEN(distid)=@tj_distlen
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--归组所有
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 4 xh, '         归组所有' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,sum(c3) qc from analysis_szqc..rep_szqc_09 where years=2017 and sumflag=( case when @tj_distlen=9 then '否' else sumflag end) and LEN(distid)=@tj_distlen and lx in('经济社','经济社公司','村(居)小组') group by distid,distname
)a full outer join (
	select distinct distid,distname,c24*10000 nb from rep901 where years=@years and LEN(distid)=@tj_distlen
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--2.园地
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 5 xh, '   2.园地' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,sum(c5) qc from analysis_szqc..rep_szqc_09 where years=2017 and sumflag=( case when @tj_distlen=9 then '否' else sumflag end) and LEN(distid)=@tj_distlen and lx in('经联社','村(居)委会','联社公司','调整数' , '经济社','经济社公司','村(居)小组') group by distid,distname
)a full outer join (
	select distinct distid,distname,c25*10000 nb from rep901 where years=@years and LEN(distid)=@tj_distlen
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--其中家庭承包
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 6 xh, '         其中家庭承包' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,sum(c5)-sum(c6) qc from analysis_szqc..rep_szqc_09 where years=2017 and sumflag=( case when @tj_distlen=9 then '否' else sumflag end) and LEN(distid)=@tj_distlen and lx in('经联社','村(居)委会','联社公司','调整数' , '经济社','经济社公司','村(居)小组') group by distid,distname
)a full outer join (
	select distinct distid,distname,c26*10000 nb from rep901 where years=@years and LEN(distid)=@tj_distlen
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--3.林地
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 7 xh, '   3.林地' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,sum(c7) qc from analysis_szqc..rep_szqc_09 where years=2017 and sumflag=( case when @tj_distlen=9 then '否' else sumflag end) and LEN(distid)=@tj_distlen and lx in('经联社','村(居)委会','联社公司','调整数' , '经济社','经济社公司','村(居)小组') group by distid,distname
)a full outer join (
	select distinct distid,distname,c27*10000 nb from rep901 where years=@years and LEN(distid)=@tj_distlen
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--其中家庭承包
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 8 xh, '         其中家庭承包' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,sum(c7)-sum(c8) qc from analysis_szqc..rep_szqc_09 where years=2017 and sumflag=( case when @tj_distlen=9 then '否' else sumflag end) and LEN(distid)=@tj_distlen and lx in('经联社','村(居)委会','联社公司','调整数' , '经济社','经济社公司','村(居)小组') group by distid,distname
)a full outer join (
	select distinct distid,distname,c28*10000 nb from rep901 where years=@years and LEN(distid)=@tj_distlen
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--4.草地
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 9 xh, '   4.草地' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,sum(c9) qc from analysis_szqc..rep_szqc_09 where years=2017 and sumflag=( case when @tj_distlen=9 then '否' else sumflag end) and LEN(distid)=@tj_distlen and lx in('经联社','村(居)委会','联社公司','调整数' , '经济社','经济社公司','村(居)小组') group by distid,distname
)a full outer join (
	select distinct distid,distname,c29*10000 nb from rep901 where years=@years and LEN(distid)=@tj_distlen
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--其中家庭承包
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 10 xh, '         其中家庭承包' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,sum(c9)-sum(c10) qc from analysis_szqc..rep_szqc_09 where years=2017 and sumflag=( case when @tj_distlen=9 then '否' else sumflag end) and LEN(distid)=@tj_distlen and lx in('经联社','村(居)委会','联社公司','调整数' , '经济社','经济社公司','村(居)小组') group by distid,distname
)a full outer join (
	select distinct distid,distname,c30*10000 nb from rep901 where years=@years and LEN(distid)=@tj_distlen
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--5.养殖水面
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 11 xh, '   5.养殖水面' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,sum(c12) qc from analysis_szqc..rep_szqc_09 where years=2017 and sumflag=( case when @tj_distlen=9 then '否' else sumflag end) and LEN(distid)=@tj_distlen and lx in('经联社','村(居)委会','联社公司','调整数' , '经济社','经济社公司','村(居)小组') group by distid,distname
)a full outer join (
	select distinct distid,distname,c31*10000 nb from rep901 where years=@years and LEN(distid)=@tj_distlen
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--其中家庭承包
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 12 xh, '         其中家庭承包' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,sum(c12)-sum(c13) qc from analysis_szqc..rep_szqc_09 where years=2017 and sumflag=( case when @tj_distlen=9 then '否' else sumflag end) and LEN(distid)=@tj_distlen and lx in('经联社','村(居)委会','联社公司','调整数' , '经济社','经济社公司','村(居)小组') group by distid,distname
)a full outer join (
	select distinct distid,distname,c32*10000 nb from rep901 where years=@years and LEN(distid)=@tj_distlen
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--6.其他
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 13 xh, '   6.其他' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,sum(c2)-sum(c3)-sum(c5)-sum(c7)-sum(c9)-sum(c12) qc from analysis_szqc..rep_szqc_09 where years=2017 and sumflag=( case when @tj_distlen=9 then '否' else sumflag end) and LEN(distid)=@tj_distlen and lx in('经联社','村(居)委会','联社公司','调整数' , '经济社','经济社公司','村(居)小组') group by distid,distname
)a full outer join (
	select distinct distid,distname,(c21-c22-c25-c27-c29-c31)*10000 nb from rep901 where years=@years and LEN(distid)=@tj_distlen
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

--------------------------
)aa group by xh,LEFT(distid,@distlen),zb
)a join (select * from dist where years=@years)b on a.distid=b.distid


)

go

