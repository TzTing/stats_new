CREATE FUNCTION [dbo].[fn_njtj005]
( 
	@years int
	--@distlen int,	--地区分组长度		省0 市2 区4 镇6 村9
	--@tj_distlen	int --从哪一级开始统计　市2 区4 镇6 村9
	
) 
RETURNS table 
AS 
RETURN (

--注意替换清产核资数据库analysis_szqc


select b.distname, a.* from (
select xh, distid, zb, 
cast(round(qc,2) as numeric(18,2)) qc, 
cast(round(nb,2) as numeric(18,2)) nb, 
cast(round(nb,2) as numeric(18,2))-cast(round(qc,2) as numeric(18,2)) ce,
(case when qc=0 then 0 else cast(round((nb-qc)*1.0/qc*100,2) as numeric(18,2)) end) zf from (
--------------------------

--总资产
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 1 xh, '总资产' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,c44*1.0/10000 qc from analysis_szqc..rep_szqc_08_1 where years=2017 and lx='汇总数'
)a full outer join (
	select distinct distid,distname,c19 nb from rep906 where years=@years and lx='汇总数'
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--其中：固定资产原值
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 2 xh, '   其中：固定资产原值' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,c26*1.0/10000 qc from analysis_szqc..rep_szqc_08_1 where years=2017 and lx='汇总数'
)a full outer join (
	select distinct distid,distname,c13 nb from rep906 where years=@years and lx='汇总数'
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--应收款项
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 3 xh, '         应收款项' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,c8*1.0/10000 qc from analysis_szqc..rep_szqc_08_1 where years=2017 and lx='汇总数'
)a full outer join (
	select distinct distid,distname,c4 nb from rep906 where years=@years and lx='汇总数'
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--总负债
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 4 xh, '总负债' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,(c34-c22)*1.0/10000 qc from analysis_szqc..rep_szqc_08_2 where years=2017 and lx='汇总数'
)a full outer join (
	select distinct distid,distname,c34 nb from rep906 where years=@years and lx='汇总数'
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--其中：应付款项
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 5 xh, '   其中：应付款项' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,c6*1.0/10000 qc from analysis_szqc..rep_szqc_08_2 where years=2017 and lx='汇总数'
)a full outer join (
	select distinct distid,distname,c22 nb from rep906 where years=@years and lx='汇总数'
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

union

--所有者权益
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 6 xh, '所有者权益' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,c22*1.0/10000 qc from analysis_szqc..rep_szqc_08_2 where years=2017 and lx='汇总数'
)a full outer join (
	select distinct distid,distname,c28 nb from rep906 where years=@years and lx='汇总数'
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')

--------------------------
)aa
)a join (select * from dist where years=@years)b on a.distid=b.distid


)
go

