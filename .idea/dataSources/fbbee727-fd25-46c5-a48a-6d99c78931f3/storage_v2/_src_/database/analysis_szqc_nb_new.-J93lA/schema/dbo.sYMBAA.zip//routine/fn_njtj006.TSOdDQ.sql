CREATE FUNCTION [dbo].[fn_njtj006]
( 
	@years int
) 
RETURNS table 
AS 
RETURN (
--注意替换清产核资数据库analysis_szqc
--总户数/总人口/总收入/集体农用地/总资产
select *,case when nhs_sn=0 then 0 else (nhs_bn-nhs_sn)/nhs_sn*100 end as nhs_zf,
		 case when rks_sn=0 then 0 else (rks_bn-rks_sn)/rks_sn*100 end as rks_zf,
		 case when zsr_sn=0 then 0 else (zsr_bn-zsr_sn)/zsr_sn*100 end as zsr_zf,
		 case when nyd_qc=0 then 0 else (nyd_bn-nyd_qc)/nyd_qc*100 end as nyd_zf,
		 case when zzc_qc=0 then 0 else (zzc_bn-zzc_qc)/zzc_qc*100 end as zzc_zf
from (
---------------------
select distinct a.years, a.distid, a.distname, 
isnull(c.c7,0)  nhs_sn, isnull(b.c7,0) nhs_bn , isnull(b.c7,0) nhs_qr, 
isnull(c.c12,0) rks_sn, isnull(b.c12,0) rks_bn, isnull(b.c12,0) rks_qr, 
isnull(f.c1,0)  zsr_sn, isnull(e.c1,0)  zsr_bn, isnull(e.c1,0) zsr_qr, 
isnull(d.c2/10000,0)  nyd_qc, isnull(c.c21,0) nyd_sn, isnull(b.c21,0) nyd_bn, isnull(b.c21,0) nyd_qr, 
isnull(i.c44/10000,0) zzc_qc, isnull(h.c19,0) zzc_sn, isnull(g.c19,0) zzc_bn, isnull(g.c19,0) zzc_qr
from dist a
left join rep901 b on a.years=b.years and a.distId=b.distid
left join (select * from rep901)c on a.years=c.years+1 and a.distId=c.distid
left join (select years,distid,sum(c2) c2 from analysis_szqc..rep_szqc_09 where years=2017 and lx in('经联社','村(居)委会','联社公司','调整数' , '经济社','经济社公司','村(居)小组') and lxname not like'%汇总数' group by years,distid) d on a.distId=d.distid
left join (select * from rep905 where lx='汇总数') e on a.years=e.years and a.distId=e.distid
left join (select * from rep905 where lx='汇总数') f on a.years=f.years+1 and a.distId=f.distid
left join (select * from rep906 where lx='汇总数') g on a.years=g.years and a.distId=g.distid
left join (select * from rep906 where lx='汇总数') h on a.years=h.years+1 and a.distId=h.distid
left join (select years,distid,sum(c44) c44 from analysis_szqc..rep_szqc_08_1 where years=2017 and lx in('经联社','村(居)委会','联社公司','调整数' , '经济社','经济社公司','村(居)小组') and lxname not like'%汇总数' group by years,distid) i on a.distId=i.distid
where a.years=@years
---------------------
)a
)
go

