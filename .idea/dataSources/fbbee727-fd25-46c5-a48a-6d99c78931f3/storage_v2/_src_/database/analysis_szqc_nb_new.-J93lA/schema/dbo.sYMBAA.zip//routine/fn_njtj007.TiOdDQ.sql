CREATE FUNCTION [dbo].[fn_njtj007]
( 
	@years int,
	@distlen int	--地区分组长度 省0 市2 区4 镇6 村9
	
) 
RETURNS table 
AS 
RETURN (

select (zs-c1) wlr, b.distname,a.* from (
select lxid,lx,years, case when left(distid,@distlen)='' then '0' else left(distid,@distlen) end distid, SUM(zs) zs, round(SUM(c1),0) c1, round(SUM(c2),0) c2, round(SUM(c3),0) c3,  round(SUM(c4),0) c4, round(SUM(c5),0) c5, round(SUM(c6),0) c6, round(SUM(c7),0) c7, round(SUM(c8),0) c8, round(SUM(c9),0) c9 from (
----------------------------------------------------------------
select distinct 1 lxid,'总收入' lx,b.years,b.distid,b.distname,b.cjlx,
--总数
1 zs,
--汇入本表村数
(case when isnull(a.distid,'')<>'' then 1 else 0 end) c1,
--<0万
(case when isnull(a.distid,'')<>'' and ISNULL(c1,0)<0 then 1 else 0 end) c2,
--=0万
(case when isnull(a.distid,'')<>'' and ISNULL(c1,0)=0 then 1 else 0 end) c3,
--0-10万
(case when isnull(a.distid,'')<>'' and ISNULL(c1,0)>0 and ISNULL(c1,0)<10 then 1 else 0 end) c4,
--10-50万
(case when isnull(a.distid,'')<>'' and ISNULL(c1,0)>=10 and ISNULL(c1,0)<50 then 1 else 0 end) c5,
--50-200万
(case when isnull(a.distid,'')<>'' and ISNULL(c1,0)>=50 and ISNULL(c1,0)<200 then 1 else 0 end) c6,
--200-1000万
(case when isnull(a.distid,'')<>'' and ISNULL(c1,0)>=200 and ISNULL(c1,0)<1000 then 1 else 0 end) c7,
--1000-10000万
(case when isnull(a.distid,'')<>'' and ISNULL(c1,0)>=1000 and ISNULL(c1,0)<10000 then 1 else 0 end) c8,
--10000万以上
(case when isnull(a.distid,'')<>'' and ISNULL(c1,0)>=10000 then 1 else 0 end) c9

from (select * from rep905 where years=@years and lx='汇总数' and LEN(distid)=9) a right join dist b on a.years=b.years and a.distid=b.distid where b.years=@years and LEN(b.distid)=9

union

select distinct 2 lxid,'本年收益' lx,b.years,b.distid,b.distname,b.cjlx,
--总数
1 zs,
--汇入本表村数
(case when isnull(a.distid,'')<>'' then 1 else 0 end) c1,
--<0万
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)<0 then 1 else 0 end) c2,
--=0万
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)=0 then 1 else 0 end) c3,
--0-10万
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)>0 and ISNULL(c13,0)<10 then 1 else 0 end) c4,
--10-50万
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)>=10 and ISNULL(c13,0)<50 then 1 else 0 end) c5,
--50-200万
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)>=50 and ISNULL(c13,0)<200 then 1 else 0 end) c6,
--200-1000万
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)>=200 and ISNULL(c13,0)<1000 then 1 else 0 end) c7,
--1000-10000万
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)>=1000 and ISNULL(c13,0)<10000 then 1 else 0 end) c8,
--10000万以上
(case when isnull(a.distid,'')<>'' and ISNULL(c13,0)>=10000 then 1 else 0 end) c9

from (select * from rep905 where years=@years and lx='汇总数' and LEN(distid)=9) a right join dist b on a.years=b.years and a.distid=b.distid where b.years=@years and LEN(b.distid)=9

union

select distinct 3 lxid,'农户分配' lx,b.years,b.distid,b.distname,b.cjlx,
--总数
1 zs,
--汇入本表村数
(case when isnull(a.distid,'')<>'' then 1 else 0 end) c1,
--<0万
(case when isnull(a.distid,'')<>'' and ISNULL(c20,0)<0 then 1 else 0 end) c2,
--=0万
(case when isnull(a.distid,'')<>'' and ISNULL(c20,0)=0 then 1 else 0 end) c3,
--0-10万
(case when isnull(a.distid,'')<>'' and ISNULL(c20,0)>0 and ISNULL(c20,0)<10 then 1 else 0 end) c4,
--10-50万
(case when isnull(a.distid,'')<>'' and ISNULL(c20,0)>=10 and ISNULL(c20,0)<50 then 1 else 0 end) c5,
--50-200万
(case when isnull(a.distid,'')<>'' and ISNULL(c20,0)>=50 and ISNULL(c20,0)<200 then 1 else 0 end) c6,
--200-1000万
(case when isnull(a.distid,'')<>'' and ISNULL(c20,0)>=200 and ISNULL(c20,0)<1000 then 1 else 0 end) c7,
--1000-10000万
(case when isnull(a.distid,'')<>'' and ISNULL(c20,0)>=1000 and ISNULL(c20,0)<10000 then 1 else 0 end) c8,
--10000万以上
(case when isnull(a.distid,'')<>'' and ISNULL(c20,0)>=10000 then 1 else 0 end) c9

from (select * from rep905 where years=@years and lx='汇总数' and LEN(distid)=9) a right join dist b on a.years=b.years and a.distid=b.distid where b.years=@years and LEN(b.distid)=9
----------------------------------------------------------------
)a group by lxid,lx,years,left(distid,@distlen)
)a join dist b on a.years=b.years and a.distid=b.distid

)
go

