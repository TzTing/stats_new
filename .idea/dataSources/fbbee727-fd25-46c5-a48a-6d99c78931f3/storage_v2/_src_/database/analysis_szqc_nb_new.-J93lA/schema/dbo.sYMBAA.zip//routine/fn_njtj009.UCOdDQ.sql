

CREATE FUNCTION [dbo].[fn_njtj009]
( 
	@years int
	
) 
RETURNS table 
AS 
RETURN (

--注意替换清产核资数据库analysis_szqc2019


select aaa.*, bbb.zb as zb2, bbb.qc as qc2, bbb.nb as nb2, bbb.ce as ce2, bbb.zf as zf2 from (

select b.distname, a.* from (
select xh, distid, zb, 
cast(round(qc,2) as numeric(18,2)) qc, 
cast(round(nb,2) as numeric(18,2)) nb, 
cast(round(nb,2) as numeric(18,2))-cast(round(qc,2) as numeric(18,2)) ce,
(case when qc=0 then 0 else cast(round((nb-qc)*1.0/qc*100,2) as numeric(18,2)) end) zf from (
--------------------------
--总资产
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 1 xh, '总资产' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,c44*1.0/10000 qc from analysis_szqc2019..rep_szqc_08_1 where years=@years and lx='汇总数'
)a full outer join (
	select distinct distid,distname,c19 nb from rep906 where years=@years and lx='汇总数'
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')
--------------------------
)aa
)a join (select * from dist where years=@years)b on a.distid=b.distid


)aaa join (


select b.distname, a.* from (
select xh, distid, zb, qc, nb, nb-qc ce,
(case when qc=0 then 0 else cast(round((nb-qc)*1.0/qc*100,2) as numeric(18,2)) end) zf from (
--------------------------
--集体农用地
select ISNULL(b.distid,a.distid) distid, ISNULL(b.distname,a.distname) distname, 1 xh, '集体农用地' zb, isnull(qc,0) qc, isnull(nb,0) nb from (
	select distinct distid,distname,c2 qc from analysis_szqc2019..rep_szqc_09 where years=@years and lx='汇总数'
)a full outer join (
	select distinct distid,distname,c21*10000 nb from rep901 where years=@years
)b on a.distid=b.distid where (a.distid like '%' or b.distId like '%')
--------------------------
)aa
)a join (select * from dist where years=@years)b on a.distid=b.distid


)bbb on aaa.distid=bbb.distid


)

go

