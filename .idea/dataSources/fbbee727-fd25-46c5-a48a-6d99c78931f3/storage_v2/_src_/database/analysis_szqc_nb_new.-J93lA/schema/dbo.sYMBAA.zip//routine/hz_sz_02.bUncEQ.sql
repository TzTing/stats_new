CREATE PROCEDURE  hz_sz_02 (@years int,@distid varchar(50) )
 
AS

begin
-------处理类型不是汇总数，lxname名中有汇总数， 注意sumflag='否'----
update rep_sz_07 set rep_sz_07.c4=round(( 
select sum(coalesce(c4,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.lx=rep_sz_07.lx and a.years=rep_sz_07.years and a.distId like rep_sz_07.distId + '%'
)
/
(select count(coalesce(c4,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.lx=rep_sz_07.lx and a.years=rep_sz_07.years and a.distId like rep_sz_07.distId + '%')

,2) where years=@years and distId like @distid+'%' and charindex('汇总数',lxname)-len(distName)>1

update rep_sz_07 set rep_sz_07.c7=round(( 
select sum(coalesce(c7,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.lx=rep_sz_07.lx and a.years=rep_sz_07.years and a.distId like rep_sz_07.distId + '%'
)
/
(select count(coalesce(c7,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.lx=rep_sz_07.lx and a.years=rep_sz_07.years and a.distId like rep_sz_07.distId + '%')

,2) where years=@years and distId like @distid+'%' and charindex('汇总数',lxname)-len(distName)>1

update rep_sz_07 set rep_sz_07.c9=round(( 
select sum(coalesce(c9,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.lx=rep_sz_07.lx and a.years=rep_sz_07.years and a.distId like rep_sz_07.distId + '%'
)
/
(select count(coalesce(c9,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.lx=rep_sz_07.lx and a.years=rep_sz_07.years and a.distId like rep_sz_07.distId + '%')

,2) where years=@years and distId like @distid+'%' and charindex('汇总数',lxname)-len(distName)>1
-----处理镇以上的汇总经联社
update rep_sz_07 set rep_sz_07.c4=round(( 
select sum(coalesce(c4,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distId like rep_sz_07.distid  + '%' and lx = '经联社'
)
/
(select count(coalesce(c4,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distId like rep_sz_07.distid + '%' and lx ='经联社' )

,2) where years=@years and distId like @distid+'%' and lx ='经联社' and sumflag='是'

update rep_sz_07 set rep_sz_07.c7=round(( 
select sum(coalesce(c7,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distId like rep_sz_07.distid  + '%' and lx = '经联社'
)
/
(select count(coalesce(c7,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distId like rep_sz_07.distid + '%' and lx ='经联社' )

,2) where years=@years and distId like @distid+'%' and lx ='经联社' and sumflag='是'

update rep_sz_07 set rep_sz_07.c9=round(( 
select sum(coalesce(c9,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distId like rep_sz_07.distid  + '%' and lx = '经联社'
)
/
(select count(coalesce(c9,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distId like rep_sz_07.distid + '%' and lx ='经联社' )

,2) where years=@years and distId like @distid+'%' and lx ='经联社' and sumflag='是'
-----处理镇以上的汇总经济社
update rep_sz_07 set rep_sz_07.c4=round(( 
select sum(coalesce(c4,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years  and a.distid like rep_sz_07.distid +'%' and lx = '经济社'
)
/
(select count(coalesce(c4,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distid like rep_sz_07.distid +'%' and lx ='经济社' )

,2) where years=@years and distId like @distid+'%' and lx ='经济社' and sumflag='是'

update rep_sz_07 set rep_sz_07.c7=round(( 
select sum(coalesce(c7,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years  and a.distid like rep_sz_07.distid +'%' and lx = '经济社'
)
/
(select count(coalesce(c7,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distid like rep_sz_07.distid +'%' and lx ='经济社' )

,2) where years=@years and distId like @distid+'%' and lx ='经济社' and sumflag='是'

update rep_sz_07 set rep_sz_07.c9=round(( 
select sum(coalesce(c9,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years  and a.distid like rep_sz_07.distid +'%' and lx = '经济社'
)
/
(select count(coalesce(c9,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distid like rep_sz_07.distid +'%' and lx ='经济社' )

,2) where years=@years and distId like @distid+'%' and lx ='经济社' and sumflag='是'
-------------处理汇总数
update rep_sz_07 set rep_sz_07.c4=round(( 
select sum(coalesce(c4,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distId like rep_sz_07.distId + '%'
)
/
(select count(coalesce(c4,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distId like rep_sz_07.distId + '%')

,2) where years=@years and distId like @distid+'%' and lx='汇总数'

update rep_sz_07 set rep_sz_07.c7=round(( 
select sum(coalesce(c7,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distId like rep_sz_07.distId + '%'
)
/
(select count(coalesce(c7,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distId like rep_sz_07.distId + '%')

,2) where years=@years and distId like @distid+'%' and lx='汇总数'

update rep_sz_07 set rep_sz_07.c9=round(( 
select sum(coalesce(c9,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distId like rep_sz_07.distId + '%'
)
/
(select count(coalesce(c9,0)) H4
from rep_sz_07 a where a.sumflag='否' and a.years=rep_sz_07.years and a.distId like rep_sz_07.distId + '%')

,2) where years=@years and distId like @distid+'%' and lx='汇总数'

end
go

