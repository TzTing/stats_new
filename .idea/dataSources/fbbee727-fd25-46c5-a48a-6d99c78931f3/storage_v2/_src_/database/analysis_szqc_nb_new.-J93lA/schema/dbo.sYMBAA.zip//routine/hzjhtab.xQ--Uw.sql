


CREATE PROCEDURE [dbo].[hzjhtab](
 @tableType varchar(30),
 @years int,
 @distType int,
 @distId varchar(30)
 
)as
	declare @jh_sql varchar(1000),@jh_tableName varchar(50)
	
	set @jh_tableName=''
	if @distType=2
	begin
	set @distId=@distId+'%'
	if @distId='0%'
	begin
	set @distId='%'
	end
	end
	
    declare hzjh cursor for select tableName from filelist where typecode=@tableType and years=@years and tableType='基本表' and tablename<>'nh907b' and tablename<>'nh907c'
      open hzjh
    fetch next from hzjh into @jh_tableName
    while (@@fetch_status=0)
    begin
    
        --set @jh_sql='update '+@jh_tableName+' set balflag=''是''  WHERE 1=1 AND years='+ + convert(varchar(4),@years)+'  AND distId like case when '''+@distId+'''=''0'' then ''%''  else '''+@distId+'%''  and sumflag=''是'' and saveflag<>''是'''
    
     set @jh_sql='update '+@jh_tableName+' set balflag=''是''  WHERE 1=1 AND years='+ + convert(varchar(4),@years)+'  AND distId like '''+@distId+''' and sumflag=''是'' and saveflag<>''是'''
     
     exec (@jh_sql)
     
    
    --  set @jh_sql='update '+@jh_tableName+' set statusno=case when balflag=''是'' then 2
				--else 1 end  WHERE 1=1 AND years='+ + convert(varchar(4),@years)+'  AND distId  like case when '''+@distId+'''=''0'' then ''%''  else '''+@distId+'%''   and sumflag=''是''  and saveflag<>''是'''
    
     set @jh_sql='update '+@jh_tableName+' set statusno=case when balflag=''是'' then 2
				else 1 end  WHERE 1=1 AND years='+ + convert(varchar(4),@years)+'  AND distId like '''+@distId+''' and sumflag=''是''  and saveflag<>''是'''
     
     exec (@jh_sql)
     --print(@jh_sql)
      fetch next from hzjh into @jh_tablename
    end
   close hzjh
   deallocate hzjh
go

