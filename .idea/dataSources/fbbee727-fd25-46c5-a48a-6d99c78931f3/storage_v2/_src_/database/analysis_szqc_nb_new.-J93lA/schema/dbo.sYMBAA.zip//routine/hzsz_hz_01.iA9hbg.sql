CREATE proc hzsz_hz_01(@years int,@distid varchar(50))
AS
begin
-- 
-- ----处理表一 注意years 要换成参数 @years ,@distid  下同 
-- begin
-- update rep_hzsz_01 set rep_hzsz_01.c1=round(aa.c1/10000,4),rep_hzsz_01.c2=round(aa.c2/10000,4)
-- from 
-- (select years,zth,coalesce(sum(c2)+sum(c4),0) c1,coalesce(sum(c3)+sum(c5),0) c2 from rep_j_hzsz_01 where years=@years group by years,zth
-- ) aa , 
-- (
-- select distinct rep_hzsz_01.years,rep_hzsz_01.distid,rep_hzsz_01.distname,distex.ztid ,distex.lx,distex.lxname from distex,rep_hzsz_01 where distex.years=rep_hzsz_01.years and distex.distid=rep_hzsz_01.distid and distex.lx=rep_hzsz_01.lx and distex.distid like @distid+'%'  and distex.tablename='rep_hzsz_01'
-- ) bb
-- where bb.ztid=aa.zth and aa.years=bb.years and bb.distid=rep_hzsz_01.distid and bb.lxname=rep_hzsz_01.lxname and bb.lx=rep_hzsz_01.lx
-- end
-- -------处理表二
-- begin
-- update rep_hzsz_01 set rep_hzsz_01.c3=round(aa.c1/10000,4),rep_hzsz_01.c4=round(aa.c2/10000,4)
-- from 
-- (select years,zth,coalesce(sum(c6),0) c1,coalesce(sum(c13),0) c2 from rep_j_hzsz_02 where years=@years group by years,zth
-- ) aa , 
-- (
-- select distinct rep_hzsz_01.years,rep_hzsz_01.distid,rep_hzsz_01.distname,distex.ztid ,distex.lx,distex.lxname from distex,rep_hzsz_01 where distex.years=rep_hzsz_01.years and distex.distid=rep_hzsz_01.distid and distex.lx=rep_hzsz_01.lx and distex.distid like @distid+'%'  and distex.tablename='rep_hzsz_01'
-- ) bb
-- where bb.ztid=aa.zth and aa.years=bb.years and bb.distid=rep_hzsz_01.distid and bb.lxname=rep_hzsz_01.lxname and bb.lx=rep_hzsz_01.lx
-- end
-- 
-- ----处理表三
-- 
-- begin
-- update rep_hzsz_01 set rep_hzsz_01.c5=round(aa.c1/10000,4),rep_hzsz_01.c6=round(aa.c2/10000,4)
-- from 
-- (select years,zth,coalesce(sum(c2),0) c1,coalesce(sum(c3),0) c2 from rep_j_hzsz_03 where years=@years group by years,zth
-- ) aa , 
-- (
-- select distinct rep_hzsz_01.years,rep_hzsz_01.distid,rep_hzsz_01.distname,distex.ztid ,distex.lx,distex.lxname from distex,rep_hzsz_01 where distex.years=rep_hzsz_01.years and distex.distid=rep_hzsz_01.distid and distex.lx=rep_hzsz_01.lx and distex.distid like @distid+'%'  and distex.tablename='rep_hzsz_01'
-- ) bb
-- where bb.ztid=aa.zth and aa.years=bb.years and bb.distid=rep_hzsz_01.distid and bb.lxname=rep_hzsz_01.lxname and bb.lx=rep_hzsz_01.lx
-- end
-- ----处理表四
-- begin
-- update rep_hzsz_01 set rep_hzsz_01.c7=0,rep_hzsz_01.c8=round(aa.c2/10000,4),rep_hzsz_01.c9=0,rep_hzsz_01.c10=round(aa.c10/10000,4)
-- from 
-- (select years,zth,coalesce(sum(c5),0) c10,coalesce(sum(c10),0) c2 from rep_j_hzsz_04 where years=@years group by years,zth
-- ) aa , 
-- (
-- select distinct rep_hzsz_01.years,rep_hzsz_01.distid,rep_hzsz_01.distname,distex.ztid ,distex.lx,distex.lxname from distex,rep_hzsz_01 where distex.years=rep_hzsz_01.years and distex.distid=rep_hzsz_01.distid and distex.lx=rep_hzsz_01.lx and distex.distid like @distid+'%'  and distex.tablename='rep_hzsz_01'
-- ) bb
-- where bb.ztid=aa.zth and aa.years=bb.years and bb.distid=rep_hzsz_01.distid and bb.lxname=rep_hzsz_01.lxname and bb.lx=rep_hzsz_01.lx
-- end
-- ------处理表五
-- 
-- begin
-- update rep_hzsz_01 set rep_hzsz_01.c11=round(aa.c1/10000,4),rep_hzsz_01.c12=round(aa.c2/10000,4),rep_hzsz_01.c13=round(aa.c3/10000,4),rep_hzsz_01.c14=round(aa.c4/10000,4)
-- from 
-- (select years,zth,coalesce(sum(c2),0) c1,coalesce(sum(c4),0) c2 ,coalesce(sum(c5),0) c3,coalesce(sum(c7),0) c4 from rep_j_hzsz_05 where years=@years group by years,zth
-- ) aa , 
-- (
-- select distinct rep_hzsz_01.years,rep_hzsz_01.distid,rep_hzsz_01.distname,distex.ztid ,distex.lx,distex.lxname from distex,rep_hzsz_01 where distex.years=rep_hzsz_01.years and distex.distid=rep_hzsz_01.distid and distex.lx=rep_hzsz_01.lx and distex.distid like @distid+'%'  and distex.tablename='rep_hzsz_01'
-- ) bb
-- where bb.ztid=aa.zth and aa.years=bb.years and bb.distid=rep_hzsz_01.distid and bb.lxname=rep_hzsz_01.lxname and bb.lx=rep_hzsz_01.lx
-- end
-- 
-- ----处理表六
-- begin
-- update rep_hzsz_01 set rep_hzsz_01.c15=aa.c1,rep_hzsz_01.c16=round(aa.c2/10000,4)
-- from 
-- (select years,zth,coalesce(count(*),0) c1,coalesce(sum(c10),0) c2  from rep_j_hzsz_06 where years=@years group by years,zth
-- ) aa , 
-- (
-- select distinct rep_hzsz_01.years,rep_hzsz_01.distid,rep_hzsz_01.distname,distex.ztid ,distex.lx,distex.lxname from distex,rep_hzsz_01 where distex.years=rep_hzsz_01.years and distex.distid=rep_hzsz_01.distid and distex.lx=rep_hzsz_01.lx and distex.distid like @distid+'%'  and distex.tablename='rep_hzsz_01'
-- ) bb
-- where bb.ztid=aa.zth and aa.years=bb.years and bb.distid=rep_hzsz_01.distid and bb.lxname=rep_hzsz_01.lxname and bb.lx=rep_hzsz_01.lx
-- end
----处理汇总表
begin
update rep_hzsz_01 set rep_hzsz_01.c1=aa.c1,rep_hzsz_01.c2=aa.c2,rep_hzsz_01.c3=aa.c3,rep_hzsz_01.c4=aa.c4,rep_hzsz_01.c5=aa.c5,rep_hzsz_01.c6=aa.c6,rep_hzsz_01.c7=aa.c7,rep_hzsz_01.c8=aa.c8,rep_hzsz_01.c9=aa.c9,rep_hzsz_01.c10=aa.c10,rep_hzsz_01.c11=aa.c12,rep_hzsz_01.c13=aa.c13,rep_hzsz_01.c14=aa.c14,rep_hzsz_01.c15=aa.c15,rep_hzsz_01.c16=aa.c16
from 
(select years,zth,coalesce(c2,0) c1,coalesce(c3,0) c2,coalesce(c4,0) c3,coalesce(c5,0) c4,coalesce(c6,0) c5,coalesce(c7,0) c6,coalesce(c8,0) c7,coalesce(c9,0) c8,coalesce(c10,0) c9,coalesce(c11,0) c10,coalesce(c12,0) c11,coalesce(c13,0) c12,coalesce(c14,0) c13,coalesce(c15,0) c14,coalesce(c16,0) c15,coalesce(c17,0) c16 from rep_j_hzsz_hz_01 where years=@years 
) aa , 
(
select distinct rep_hzsz_01.years,rep_hzsz_01.distid,rep_hzsz_01.distname,distex.ztid ,distex.lx,distex.lxname from distex,rep_hzsz_01 where distex.years=rep_hzsz_01.years and distex.distid=rep_hzsz_01.distid and distex.lx=rep_hzsz_01.lx and distex.distid like @distid+'%'  and distex.tablename='rep_hzsz_01'
) bb
where bb.ztid=aa.zth and aa.years=bb.years and bb.distid=rep_hzsz_01.distid and bb.lxname=rep_hzsz_01.lxname and bb.lx=rep_hzsz_01.lx
end

end
go

