
CREATE procedure [dbo].[peizhiDist_san](
 @toDistid varchar(150),
 @topimport_distNo varchar(150),
 @str varchar(150),
 @years int,
 @distname1 varchar(100)
)as
begin
declare @sql varchar(4000),@distIdParent varchar(150),@befor_distIdParent varchar(150),@distid varchar(150),@distname varchar(150),@months int
,@import_distNo varchar(150),@len int,@imlen int,@topImlen int
--,@toDistid varchar(100),@str varchar(100),@years int
--set @toDistid='12'
--set @str='' 
--set @years=2014
set @befor_distIdParent='-1'
set @topImlen=LEN(@topimport_distNo)
set @imlen=LEN(@topimport_distNo)
--if not exists (select * from dist where years=@years and distId=''+@toDistid+'' and distName=''+@distname1+'')
update dist set import_distNo=''+@topimport_distNo+''  where years=@years and distId=''+@toDistid+'' and distName=''+@distname1+''

--未配置第三方编号



declare distlen cursor for 
 select len(distid) as dslen from dist where years=@years and distid like +@toDistid+'%' 
    --and (import_distNo is  null or import_distNo ='') 
 group by len(distid) order by  len(distid)
open distlen
fetch next from distlen into @len
while @@FETCH_STATUS=0
begin

--不重复地区名
update dist set import_distNo=dd.tmp from(
select dist.years,dist.distId,d.distId as tmp
from dist, ( 
select * from dist_temp where years=@years and distid like +@topimport_distNo+'%'   and LEN(distid)=@topImlen
and distname not in(SELEct distName from dist_temp where 1=1 and  years=@years  and distId like +@topimport_distNo+'%' group by distName having COUNT(*)>1))d
where dist.years=@years and dist.distName=d.distName and dist.distId like +@toDistid+'%'  and LEN(dist.distid)=@len
and dist.distname not in(SELEct distName from dist where 1=1 and  years=@years  and distId like +@toDistid+'%' group by distName having COUNT(*)>1)
 )dd
where dist.years=@years and dist.distId=dd.distId
---



declare ds cursor for 
 select years,distname,distIdParent from dist where years=@years and distid like +@toDistid+'%'   and (import_distNo is  null or import_distNo ='') and len(distid)=@len  and  LEN(distname)<>0
  order by  distIdParent

open ds
fetch next from ds into  @years,@distname,@distIdParent
while @@FETCH_STATUS=0
begin
--	if LEN(@distIdParent)=6 and 
    if @distIdParent<>@befor_distIdParent
	begin
	set @befor_distIdParent=@distIdParent
	select @import_distNo=import_distNo from dist where years=@years and distid like +@toDistid+'%' and distId like +@distIdParent+'' 
		if @import_distNo<>'' and len(@import_distNo)>0
		begin
		--if @topimport_distNo<>@import_distNo
		--set @imlen=LEN(@import_distNo)
		--else --@str='村' 
			begin
			declare @short_str varchar(150)
			declare splits cursor for select short_str from F_SQLSERVER_SPLIT(@str,',')
			open splits
			fetch next from splits into @short_str
			while @@FETCH_STATUS=0
			begin
				if @short_str='1'
				begin
				update dist set import_distNo=d.distId from (
				select years,distId,distName from dist_temp where years=@years and distid like +@import_distNo+'%' 
						and distId like +@import_distNo+'%' and len(distid)=@imlen)d
				where dist.years=@years and dist.distId like +@toDistid+'%' and dist.distId like +@distIdParent+'%' 
				and LEN(dist.distid)=@len and d.distName like +dist.distName+'%'
				
				--
				update dist set import_distNo=d.distId from (
				select years,distId,distName from dist_temp where years=@years and distid like +@import_distNo+'%' 
						and distId like +@import_distNo+'%' and len(distid)=@imlen)d
				where dist.years=@years and dist.distId like +@toDistid+'%' and dist.distId like +@distIdParent+'%' 
				and LEN(dist.distid)=@len and dist.distName like +d.distName+'%'
				
				end
				
				if @short_str<>'1'
				 begin
					update dist set import_distNo=d.distId from (
						select years,distId,SUBSTRING(distName,0,CHARINDEX(@short_str,distName)) as distName		from dist_temp 
								where years=@years and distid like +@import_distNo+'%'	and len(distid)=@imlen				
					 and CHARINDEX(@short_str,distName)<>0)d
					where dist.years=@years and dist.distId like +@toDistid+'%' and dist.distId like +@distIdParent+'%' and dist.distName=d.distName and LEN(dist.distId)=@len
				end
			
				fetch next from splits into @short_str
			end
			close splits
			deallocate splits					
			end	
		
		
		end
	end

fetch next from ds into @years,@distname,@distIdParent
end
close ds
 deallocate ds
set @imlen=@imlen+3
set @topImlen=@topImlen+3
fetch next from distlen into @len
end
close distlen
deallocate distlen
end
go

