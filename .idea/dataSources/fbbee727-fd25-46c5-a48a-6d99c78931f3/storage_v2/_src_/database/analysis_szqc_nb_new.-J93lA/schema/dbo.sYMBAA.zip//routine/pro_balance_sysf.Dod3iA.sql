


CREATE PROCEDURE [dbo].[pro_balance_sysf]
  @timeid varchar(150),
  @years int,
  @months int,
  @dbaccount varchar(50),
  @acc_code varchar(50),
  @acc_modal varchar(50)
   
AS
 declare @sql varchar(5000)
 set @sql=''
BEGIN
 -- exec('IF EXISTS (SELECT * FROM dbo.balance_tem WHERE timeid = '''+@timeid+''')
  --delete from  dbo.balance_tem  where timeid='''+@timeid+'''')
   exec('IF EXISTS (SELECT * FROM dbo.balance_tem )
  delete from  dbo.balance_tem ')
  set @sql=
'insert into dbo.balance_tem(years,acc_set, acc_code,bal_month_end,bal_month_begin, debit_month, credit_month, timeid)
 select '++convert(varchar(50),@years)++' as years,
	acc_set,acc_code,isnull((select sum(bal_month_end)  from '+@dbaccount+'.dbo.balance bm

 	 where bm.years*12+bm.months='+convert(varchar(50),@years)+'*12+'+convert(varchar(50),@months)+' 
 	and bm.acc_set=bs.acc_set and bm.acc_code=bs.acc_code
 	group by bm.acc_set,bm.acc_code
 	
 	),0)as
	bal_month_end,
	isnull(
	
	(select   sum(bal_month_begin)   from '+@dbaccount+'.dbo.balance bc
		 where years*12+months='+convert(varchar(50),@years)+'*12+'+convert(varchar(50),@months)+'-36+1
		    and bc.acc_set=bs.acc_set and bc.acc_code=bs.acc_code group by bc.acc_set,bc.acc_code
		 ),0)as
		 bal_month_begin,
	debit_month,credit_month,'''+@timeid+''' as timeid
	 from (	 
			 select bs.acc_set,bs.acc_code,
				sum(debit_month) as debit_month,sum(credit_month) as credit_month from '+@dbaccount+'.dbo.balance bs,
				(select c.acc_set,c.acc_code   from '+@dbaccount+'.dbo.acc_code c,
				
				(select linkdistid,acc_set from '+@dbaccount+'.dbo.acc_set where acc_modal in('+@acc_modal+') )a
							where lastflag=1 and c.years='+convert(varchar(50),@years)+' and (acc_code like ''112%'' or acc_code like ''202%'') 
							and c.acc_set=a.acc_set
				)ac
					 where bs.years*12+bs.months>'+convert(varchar(50),@years)+'*12+'+convert(varchar(50),@months)+'-36 
					 and (bs.acc_code like ''112%'' or bs.acc_code like ''202%'')
					and bs.acc_set=ac.acc_set  and bs.acc_code=ac.acc_code  
					 group by bs.acc_set,bs.acc_code
		 		 )
		 bs'
  exec (@sql)
  
  set @sql=''
  set @sql=' update balance_tem set bal_years_3=h.bal_years_3,bal_years=h.bal_years
  from(
 select 
  acc_set,acc_code,
 isnull(case when bal_month_begin-credit_month>0 then debit_month
 when bal_month_begin-credit_month<0 then bal_month_end end,0) as bal_years_3,
 
 isnull(case when bal_month_begin-credit_month>0 then  bal_month_begin-credit_month
 when bal_month_begin-credit_month<0 then 0 end,0) as bal_years
   from balance_tem
 where acc_code like ''112%'')h
 where balance_tem.acc_set =h.acc_set and balance_tem.acc_code=h.acc_code'
 
  exec (@sql)
  
  set @sql=''
  set @sql=' update balance_tem set bal_years_3=h.bal_years_3,bal_years=h.bal_years
  from(
 select 
  acc_set,acc_code,
 isnull(case when bal_month_begin-debit_month>0 then credit_month
 when bal_month_begin-debit_month<0 then bal_month_end end,0) as bal_years_3,
 
 isnull(case when bal_month_begin-debit_month>0 then  bal_month_begin-debit_month
 when bal_month_begin-debit_month<0 then 0 end,0) as bal_years
   from balance_tem
 where acc_code like ''202%'')h
 where balance_tem.acc_set =h.acc_set and balance_tem.acc_code=h.acc_code'
  exec (@sql)
END
go

