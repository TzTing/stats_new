 
  
CREATE PROCEDURE [dbo].[removeEmpty]
       @distid varchar(100),
       @typeCode varchar(100),
       @years int,
       @beginmonths int,
       @endmonths int,
       @tablename varchar(50)
      
AS
 declare @fieldSql varchar(4000)
  declare @fieldName varchar(50)
  declare @columns varchar(4000)
  declare @ismonths varchar(500)
BEGIN

set @ismonths=''
set @columns=''
  declare fileItemBytab cursor for select fieldname from fileitem where tablename=@tablename and years=@years and RTRIM(LTRIM(fieldname)) like 'c%' order by disId
          open fileItemBytab
          fetch next from fileItemBytab into @fieldName
          while @@FETCH_STATUS=0
           begin
           set @columns+=@fieldName+'=isnull('+@fieldName+',0),'
         -- set @fieldSql='update '+@tablename +' set '+@fieldName+'=isnull('+@fieldName+',0) where years='+CONVERT(varchar(50),@years)+@ismonths
          --exec(@fieldSql)
          fetch next from fileItemBytab into @fieldName
           end
          close fileItemBytab
          deallocate fileItemBytab
          
          if @beginmonths<>0
           begin
            set @ismonths=' and years*12+months>=years*12+'+CONVERT(varchar(50),@beginmonths)+' and years*12+months<=years*12+'+CONVERT(varchar(50),@endmonths)
           end
		 --set @fieldSql='update '+@tablename +' set '+ subString(@columns,0,LEN(@columns)) +' where years='+CONVERT(varchar(50),@years)+@ismonths
		  set @fieldSql='update '+@tablename +' set '+ subString(@columns,0,LEN(@columns)) +' where years='+CONVERT(varchar(50),@years)+@ismonths+' and distid like case when '''+@distid+'''=''0'' then ''%'' else '''+@distid+'%'' end'
          exec(@fieldSql)
      --  print @fieldSql
	
END
go

