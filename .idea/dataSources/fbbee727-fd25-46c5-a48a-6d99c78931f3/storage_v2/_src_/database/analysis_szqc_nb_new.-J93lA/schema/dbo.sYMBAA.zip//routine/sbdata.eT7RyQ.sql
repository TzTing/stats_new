
CREATE PROCEDURE [dbo].[sbdata](
 @keyword varchar(100),
 @udistno varchar(20),
 @username varchar(100),
 @issb bit 
)
as
begin
 declare @id int, @distNo varchar(50), @distName varchar(50), @years int, @okflag bit,@issbbefor bit,
	@reason varchar(8000),@tablename varchar(50),@sql varchar(1000),@months int,@tableDis varchar(50),
	@optType int,@isDeleteTab int,@tableType varchar(50),@monthssql varchar(1000)
set @sql=''
set @okflag=1
set @reason='${reason}'
set @id=SUBSTRING(@keyword, 0, charindex('_', @keyword))
set @distNo=SUBSTRING(@keyword, charindex('_', @keyword) + 1, LEN(@keyword))
set @issbbefor=0
set @monthssql=''
select @years=uploadBase.years,@months=uploadBase.months,@tableType=tableType.tableType from tableType inner join uploadBase on tableType.tableType=uploadBase.tableType 
	 and uploadBase.runflag=1
	where uploadBase.id=@id
SELECT @distName=distname from dist where distId=@distNo and years=@years


--上报
if @issb=1
begin
if not exists(SELECT * from  uploadBase 
	WHERE  years=CONVERT(varchar(10),@years) AND distno like case when @distNo='0' then '%' else ''+@distNo+'%' end and runflag=1 and okflag=1 and sbflag=1 and tableType=@tableType)
	begin
	update uploadBase set sbflag=1,okflag=1,bdate=GETDATE(),writer=''+@username+''	WHERE years=CONVERT(varchar(10),@years) AND months=CONVERT(varchar(5),@months) AND distno=''+@distNo+'' and runflag=1 and okflag=0 and tableType=@tableType
	update uploadBase set okflag=1,bdate=GETDATE(),writer=''+@username+''	WHERE  years=CONVERT(varchar(10),@years) AND months=CONVERT(varchar(5),@months)  AND distno<>''+@distNo+'' and  distno like ''+@distNo+'%' and runflag=1 and okflag=0 and tableType=@tableType and not exists(select * from uploadBase uu where uu.years=uploadBase.years and uu.months=uploadBase.months and uu.runflag=1 and uu.okflag=1 and uu.distno=uploadBase.distno and uu.tableType=uploadBase.tableType)
	end
	else
	begin
	update uploadBase set okflag=1,bdate=GETDATE(),writer=''+@username+''	WHERE  years=CONVERT(varchar(10),@years) AND months=CONVERT(varchar(5),@months) and  distno like  ''+@distNo+'%' and runflag=1 and okflag=0 and tableType=@tableType
	and not exists(select * from uploadBase uu where uu.years=uploadBase.years and uu.months=uploadBase.months  and uu.runflag=1 and uu.okflag=1 and uu.distno=uploadBase.distno and uu.tableType=uploadBase.tableType)
	end
end
else
begin
if  exists(SELECT * from  uploadBase 
	WHERE  years=CONVERT(varchar(10),@years) AND distno like case when @distNo='0' then '%' else ''+@distNo+'' end and runflag=1 and okflag=1 and sbflag=1 and tableType=@tableType)
	begin
	set @issbbefor=1
	update uploadBase set sbflag=0,okflag=0,bdate=null,edate=GETDATE(),writer=''+@username+'' WHERE years=CONVERT(varchar(10),@years) AND months=CONVERT(varchar(5),@months) AND distno=''+@distNo+'' and runflag=1 and okflag=1 and distno<>''+@udistno+'' and tableType=@tableType
	update uploadBase set okflag=0,bdate=null,edate=GETDATE(),writer=''+@username+''	WHERE  years=CONVERT(varchar(10),@years) AND months=CONVERT(varchar(5),@months) AND distno<>''+@distNo+'' and  distno like ''+@distNo+'%' and runflag=1 and okflag=1 and tableType=@tableType and not exists(select * from uploadBase uu where uu.years=uploadBase.years and uu.months=uploadBase.months  and uu.runflag=1 and uu.okflag=0 and uu.distno=uploadBase.distno and uu.tableType=uploadBase.tableType) and distno<>''+@udistno+''
	end
	else
	begin
	update uploadBase set okflag=0,bdate=null,edate=GETDATE(),writer=''+@username+''	WHERE  years=CONVERT(varchar(10),@years) AND months=CONVERT(varchar(5),@months) and  distno =  ''+@distNo+'' and runflag=1 and okflag=1 and tableType=@tableType
	and not exists(select * from uploadBase uu where uu.years=uploadBase.years and uu.months=uploadBase.months and uu.runflag=1 and uu.okflag=0 and uu.distno=uploadBase.distno and uu.tableType=uploadBase.tableType) and distno<>''+@udistno+''
	end 

end

--基表
declare tab cursor for  SELECT uploadBase.years, uploadBase.months, fileList.tableName, fileList.tableDis, tableType.optType,isDeleteTab
         from uploadBase inner join fileList
          on uploadBase.tableType=fileList.typeCode and filelist.tableType='基本表'   and uploadBase.years=fileList.years		inner join tableType
           on uploadBase.tableType=tableType.tableType    
        where uploadBase.id=@id 

open tab
fetch next from tab into @years,@months,@tablename,@tableDis,@optType,@isDeleteTab
while @@FETCH_STATUS=0
begin
if @optType=2 or @optType=3
	set @monthssql=' and isnull(months,0)='+CONVERT(varchar(10),@months)

if @issb=1
begin

set @sql=' update '+@tablename+' set okflag=1,statusno=3,saveflag=''是'',upReportTime=GETDATE() where years='+CONVERT(varchar(10),@years)+@monthssql+' and distid like '''+@distno+'%'' and  isnull(okflag,0)=0 '
exec(@sql)
end
else
begin

if @issbbefor=1
begin
set @sql=' update '+@tablename+' set okflag=0,statusno=2,saveflag=''否'',upReportTime=null where years='+CONVERT(varchar(10),@years)+@monthssql+' and distid like '''+@distno+'%'' and okflag=1 and distid<>'''+@udistno+''''

	exec(@sql)
	--if @isDeleteTab=1
	--begin
	--set @sql='delete  from '+@tablename+' where years='+CONVERT(varchar(10),@years)+@monthssql+' and distid like '''+@distNo+'%'' and saveflag=''否'' and okflag=0'
	----print @sql
	--exec(@sql)
	--end
end
else
begin
set @sql=' update '+@tablename+' set okflag=0,statusno=2,saveflag=''否'',upReportTime=null where years='+CONVERT(varchar(10),@years)+@monthssql+' and distid = '''+@distno+''' and okflag=1 and distid<>'''+@udistno+''''
exec(@sql)
end
end

fetch next from tab into @years,@months,@tablename,@tableDis,@optType,@isDeleteTab
end
close tab
 deallocate tab
 end
go

