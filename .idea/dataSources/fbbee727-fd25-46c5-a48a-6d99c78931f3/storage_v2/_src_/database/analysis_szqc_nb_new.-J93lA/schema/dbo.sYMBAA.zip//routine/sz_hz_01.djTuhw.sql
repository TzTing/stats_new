CREATE PROCEDURE  sz_hz_01(@years int,@distid varchar(50))
AS
begin
----处理表一 注意years 要换成参数 @years ,@distid  下同 
if exists (select distinct ww.* from  rep_zqsz_01 ww,distex jj where ww.years=jj.years and jj.ztid=ww.zth ) ---and jj.years=：年
begin
update rep_sz_01 set rep_sz_01.c1=aa.c1,rep_sz_01.c4=round(aa.c4/10000,4),rep_sz_01.c5=round(aa.c5/10000,4),rep_sz_01.c6=round(aa.c6/10000,4),rep_sz_01.c7 =round(aa.c7/10000,4),rep_sz_01.c8 =round(aa.c8/10000,4),rep_sz_01.c9 =round(aa.c9/10000,4),rep_sz_01.c10 =round(aa.c10/10000,4),rep_sz_01.c11 =round(aa.c11/10000,4) 
from 
(select years,zth,coalesce(count(c4),0) c1 ,coalesce(sum(c4),0) c4,coalesce(sum(c5),0) c5,coalesce(sum(c6),0) c6, coalesce(sum(c6)-sum(c5),0) as  c7,
coalesce(sum(c8),0) c8,coalesce(sum(c9),0) c9,coalesce(sum(c10),0) c10,coalesce((sum(c10)-sum(c8)),0) as c11 from rep_zqsz_01 where years=@years group by years,zth
) aa , 
(select distinct rep_sz_01.years,rep_sz_01.distid,rep_sz_01.distname,distex.ztid ,distex.lx,distex.lxname from distex,rep_sz_01 where distex.years=rep_sz_01.years and distex.distid=rep_sz_01.distid and distex.lx=rep_sz_01.lx and distex.distid like @distid+'%'  and distex.tablename='rep_sz_01') bb
where bb.ztid=aa.zth and aa.years=bb.years and bb.distid=rep_sz_01.distid and bb.lxname=rep_sz_01.lxname and bb.lx=rep_sz_01.lx
end



end
go

