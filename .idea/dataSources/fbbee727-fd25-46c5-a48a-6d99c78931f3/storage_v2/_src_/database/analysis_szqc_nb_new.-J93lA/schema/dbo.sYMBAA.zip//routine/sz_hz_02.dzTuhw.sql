CREATE PROCEDURE  sz_hz_02(@years int,@distid varchar(50))
AS
begin

---处理表二
if exists (select distinct ww.* from  rep_zqsz_02 ww,distex jj where ww.years=jj.years and jj.ztid=ww.zth ) ---and jj.years=：年
begin
update rep_sz_02 set rep_sz_02.c2= aa.w2,rep_sz_02.c3=aa.w3,rep_sz_02.c4=aa.w4,rep_sz_02.c5 =round(aa.w5/10000,4),rep_sz_02.c6 =round(aa.w6/10000,4),rep_sz_02.c7 =round(aa.w7/10000,4),rep_sz_02.c8 =round(aa.w8/10000,4),rep_sz_02.c12=aa.w12,rep_sz_02.c13=aa.w13,rep_sz_02.c14=aa.w14,rep_sz_02.c15 =round(aa.w15/10000,4),rep_sz_02.c16=aa.w18,rep_sz_02.c17=aa.w19,rep_sz_02.c18=aa.ger,rep_sz_02.c19=aa.xiaoz,rep_sz_02.c20=aa.baof
from 
(select ww.years,ww.zth,sum(ww.c2) w2,sum(ww.c3) w3,sum(ww.c4) w4,sum(ww.c5) w5,sum(ww.c6) w6,sum(ww.c7) w7,sum(ww.c8) w8,sum(ww.c12) w12,sum(ww.c13) w13,sum(ww.c14) w14,sum(ww.c15) w15,sum(ww.c18) w18,sum(ww.c19) w19, sum(ww.ger) ger,sum(ww.xianz) xiaoz,sum(ww.baof) baof
from(
select r2.years,r2.zth,coalesce(count(r2.c1),0) c2, coalesce(case when r2.c4=0 then count(r2.c4) else 0 end ,0) c3,coalesce(case when r2.c4=1 then count(r2.c4) else 0 end ,0) c4,
coalesce (sum(r2.c5),0) c5,coalesce(sum(r2.c6),0) c6,coalesce(sum(r2.c7),0) c7,coalesce(sum(r2.c8),0) c8, coalesce(sum(r2.c12) ,0) c12,coalesce(sum(r2.c13) ,0) c13,coalesce(sum(r2.c14) ,0) c14,coalesce(sum(r2.c17) ,0) c15,coalesce(case when r2.c18=1 then count(r2.c18) else null end  ,0) c18,coalesce(case when r2.c19=1 then count(r2.c19) else null end  ,0) c19,coalesce(sum(r2.c20),0) ger,coalesce(sum(r2.c21),0) xianz,coalesce(sum(r2.c22),0) baof
from (select zth,years,months,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,case when c12 like '自用%' then 1 when c12 like '自营%' then 1 else 0 end c12,case when isnumeric(c13)<>0 then cast(c13 as money) else 0 end c13,case when c14<>'' then 1 else 0 end c14,c15,c16,c17,c18,c19,case when isnumeric(c20)<>0 then cast(c20 as money) else null end c20,case when isnumeric(c21)<>0 then cast(c21 as money) else null end c21,case when isnumeric(c22)<>0 then cast(c22 as money) else null end c22 from rep_zqsz_02 ) r2 
where r2.years=@years group by r2.years,r2.zth,r2.c4,r2.c18,r2.c19) ww group by ww.years,ww.zth


) aa,
(select distinct rep_sz_02.years,rep_sz_02.distid,rep_sz_02.distname,distex.ztid,distex.lx,distex.lxname from distex,rep_sz_02 where distex.years=rep_sz_02.years and distex.distid=rep_sz_02.distid and distex.lx=rep_sz_02.lx and distex.distid like @distid+'%'  and distex.tablename='rep_sz_02') bb
where bb.ztid=aa.zth and aa.years=bb.years and bb.distid=rep_sz_02.distid and bb.lx=rep_sz_02.lx and bb.lxname=rep_sz_02.lxname 
end



end
go

