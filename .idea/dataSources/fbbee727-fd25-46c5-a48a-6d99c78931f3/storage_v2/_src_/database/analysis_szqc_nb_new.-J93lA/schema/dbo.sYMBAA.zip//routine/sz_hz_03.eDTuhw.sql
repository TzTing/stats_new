CREATE PROCEDURE  sz_hz_03(@years int,@distid varchar(50))
AS
begin


--处理表三
if exists (select distinct ww.* from  rep_zqsz_03 ww,distex jj where ww.years=jj.years and jj.ztid=ww.zth ) ---and jj.years=：年
begin
update rep_sz_03 set rep_sz_03.c1=aa.c1,rep_sz_03.c2 =round(aa.c2/10000,4),rep_sz_03.c3 =round(aa.c3/10000,4),rep_sz_03.c4 =round(aa.c4/10000,4),rep_sz_03.c5 =round(aa.c5/10000,4),rep_sz_03.c6 =round(aa.c6/10000,4),rep_sz_03.c7 =round(aa.c7/10000,4),rep_sz_03.c8 =round(aa.c8/10000,4),rep_sz_03.c9 =round(aa.c9/10000,4),rep_sz_03.c10 =round(aa.c10/10000,4),rep_sz_03.c11 =round(aa.c11/10000,4),rep_sz_03.c12 =round(aa.c12/10000,4),rep_sz_03.c15=aa.c15,rep_sz_03.c16=aa.c16,rep_sz_03.c17=aa.c17,rep_sz_03.c18=aa.c18,rep_sz_03.c19=aa.c19
from 
(select years,zth, coalesce(count(c1),0) c1,coalesce(sum(c2),0) c2,coalesce(sum(c3),0) c3,coalesce(sum(c4),0) c4,coalesce(sum(c5),0) c5,coalesce(sum(c6),0) c6,coalesce(sum(c7),0) c7,coalesce(sum(c8),0) c8,coalesce(sum(c9),0) c9,coalesce(sum(c10),0) c10,coalesce(sum(c11),0) c11,coalesce(sum(c12),0) c12,sum(cast(coalesce(c15,0) as int)) c15, sum(cast(coalesce(c16,0) as int)) c16,sum(cast(coalesce(c17,0) as int)) c17,
sum(cast(coalesce(c18,0) as int)) c18,sum(cast(coalesce(c19,0) as int)) c19
from rep_zqsz_03 where years=@years group by years,zth) aa,
(select distinct rep_sz_03.years,rep_sz_03.distid,rep_sz_03.distname,distex.ztid,distex.lx,distex.lxname from distex,rep_sz_03 where distex.years=rep_sz_03.years and distex.distid=rep_sz_03.distid and distex.lx=rep_sz_03.lx and distex.distid like @distid+'%'  and distex.tablename='rep_sz_03') bb
where bb.ztid=aa.zth and aa.years=bb.years and bb.distid=rep_sz_03.distid  and bb.lx=rep_sz_03.lx and bb.lxname=rep_sz_03.lxname 
end




end
go

