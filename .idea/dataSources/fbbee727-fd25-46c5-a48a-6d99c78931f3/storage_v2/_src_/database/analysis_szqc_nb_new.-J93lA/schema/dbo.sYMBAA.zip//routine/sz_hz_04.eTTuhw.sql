CREATE PROCEDURE  sz_hz_04(@years int,@distid varchar(50))
AS
begin

--处理表四

if exists (select distinct ww.* from  rep_zqsz_04 ww,distex jj where ww.years=jj.years and jj.ztid=ww.zth ) ---and jj.years=：年
begin
update rep_sz_04 set rep_sz_04.c1=aa.c1,rep_sz_04.c2 =round(aa.c2/10000,4),rep_sz_04.c3 =round(aa.c3/10000,4),rep_sz_04.c4=aa.c4,rep_sz_04.c5=aa.c5,rep_sz_04.c7=aa.c7,rep_sz_04.c8=aa.c8,rep_sz_04.c9=aa.c9,rep_sz_04.c10=aa.c10
from
(select years,zth,coalesce(count(c1),0) c1,coalesce(sum(c2),0) c2,coalesce(sum(c3),0) c3,coalesce(count(c4),0) c4,coalesce(count(c5),0) c5,sum(cast(coalesce(c7,0) as int)) c7,sum(cast(coalesce(c8,0) as int)) c8,sum(cast(coalesce(c9,0) as int)) c9,sum(cast(coalesce(c10,0) as int)) c10
from rep_zqsz_04 where years=@years group by years,zth
) aa,
(select distinct rep_sz_04.years,rep_sz_04.distid,rep_sz_04.distname,distex.ztid,distex.lx,distex.lxname from distex,rep_sz_04 where distex.years=rep_sz_04.years and distex.distid=rep_sz_04.distid and distex.lx=rep_sz_04.lx and distex.distid like @distid+'%'  and distex.tablename='rep_sz_04') bb
where bb.ztid=aa.zth and aa.years=bb.years and bb.distid=rep_sz_04.distid and bb.lx=rep_sz_04.lx and bb.lxname=rep_sz_04.lxname 
end




end
go

