CREATE PROCEDURE  sz_hz_05(@years int,@distid varchar(50))
AS
begin


--处理表五
if exists (select distinct ww.* from  rep_zqsz_05 ww,distex jj where ww.years=jj.years and jj.ztid=ww.zth ) ---and jj.years=：年
begin
update rep_sz_05 set rep_sz_05.c3 =aa.w3,rep_sz_05.c4 =aa.w4,rep_sz_05.c8 =aa.w8,rep_sz_05.c9 =round(aa.w9/10000,4),rep_sz_05.c10 =aa.w10,rep_sz_05.c11 =aa.w11,rep_sz_05.c16 =aa.w16,rep_sz_05.c18 =round(aa.w18/10000,4),rep_sz_05.c20 =aa.w20,rep_sz_05.c21 =aa.w21
from
(select ww.years,ww.zth, sum(ww.c3) w3,sum(coalesce(ww.c4,0) ) w4,
sum(ww.c8) w8,sum(ww.c9) w9,sum(ww.c10) w10,sum(ww.c11) w11,sum(ww.c16) w16,sum(ww.c18) w18,sum(ww.c20) w20,sum(ww.c21) w21
from
(select r5.years,r5.zth,coalesce(sum(r5.c3),0) c3,sum(coalesce(r5.c4,0)) c4,
coalesce(sum(r5.c8),0) c8,coalesce(sum(r5.c9),0) c9,case when r5.c11=1 then sum(coalesce(r5.c8,0)) else 0 end c10,case when r5.c12=1 then sum(coalesce(r5.c8,0)) else 0 end c11,coalesce(sum(r5.c16),0) c16,coalesce(sum(r5.c18),0) c18, case when r5.c20=1 then sum(coalesce(r5.c16,0)) else 0 end c20,case when r5.c21=1 then sum(coalesce(r5.c16,0)) else 0 end c21
from (select zth,years,c1,c2,c3,case when isnumeric(c4)<>0 then cast(c4 as money) else null end c4, c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20,c21,c22 from rep_zqsz_05) r5 
where r5.years=@years group by r5.years,r5.zth,r5.c11,r5.c12,r5.c20,r5.c21 ) ww   group by ww.years,ww.zth

) aa,
(select distinct rep_sz_05.years,rep_sz_05.distid,rep_sz_05.distname,distex.ztid ,distex.lx,distex.lxname from distex,rep_sz_05 where distex.years=rep_sz_05.years and distex.distid=rep_sz_05.distid and distex.lx=rep_sz_05.lx and distex.distid like @distid+'%'  and distex.tablename='rep_sz_05') bb
where bb.ztid=aa.zth and aa.years=bb.years and bb.distid=rep_sz_05.distid and bb.lx=rep_sz_05.lx and bb.lxname=rep_sz_05.lxname 

end




end
go

