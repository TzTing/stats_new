CREATE PROCEDURE  sz_hz_06(@years int,@distid varchar(50))
AS
begin


--处理表六
---if exists (select distinct ww.* from  rep_zqsz_06 ww,distex jj where ww.years=jj.years and jj.ztid=ww.zth ) ---and jj.years=：年
begin
update rep_sz_06 set rep_sz_06.c1 =round(aa.c1/10000,4),rep_sz_06.c2 =round(aa.c2/10000,4),rep_sz_06.c3 =round(aa.c3/10000,4),rep_sz_06.c4 =round(aa.c4/10000,4),rep_sz_06.c5 =round(aa.c5/10000,4),rep_sz_06.c6 =round(aa.c6/10000,4)
from
(select jj.years,jj.zth,sum(jj.c1) c1,sum(jj.c2) c2,sum(jj.c3) c3,sum(jj.c4) c4,sum(jj.c5) c5,sum(jj.c6) c6
from
(select ww.* from 
--债权
(select years,zth,coalesce(sum(c5),0) c1,coalesce(sum(c6),0) c2,coalesce(sum(c6),0) c3,0 c4,0 c5,0 c6
from rep_zqsz_06 where years=@years group by years,zth) ww
union all
--债务
select years,zth,0 c1,0 c2,0 c3,coalesce(sum(c5),0) c4,coalesce(sum(c6),0) c5,coalesce(sum(c6),0) c6
from rep_zqsz_07 where years=@years group by years,zth ) jj group by jj.years,jj.zth
) aa,
(select distinct  rep_sz_06.years,rep_sz_06.distid,rep_sz_06.distname,distex.ztid,distex.lx,distex.lxname from distex,rep_sz_06 where distex.years=rep_sz_06.years and distex.distid=rep_sz_06.distid and distex.lx=rep_sz_06.lx and distex.distid like @distid+'%'  and distex.tablename='rep_sz_06') bb
where bb.ztid=aa.zth and aa.years=bb.years and bb.distid=rep_sz_06.distid and bb.lx=rep_sz_06.lx and bb.lxname=rep_sz_06.lxname 
end



end
go

