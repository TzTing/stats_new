
CREATE PROCEDURE  [dbo].[table_situation_pro]
	@years int,
	@months int,
	@tabletype varchar(100),
	@distno varchar(100),
	@userid int,
	@zcjydb varchar(100)
	
AS
BEGIN
	declare @sql varchar(5000)
	declare @sql2 varchar(5000)
	declare @tablename varchar(100)
	declare @sqlMonths varchar(200)
	declare @sqlMonths1 varchar(200)
	declare @columnMonths varchar(100)
	declare @columnMonths1 varchar(100)
	declare @tabWhereMonths varchar(100)
	declare @existsLx int
	
	set @sql=''
	set @sql2=''
	set @sqlMonths=''
	set @sqlMonths1=''
	set @columnMonths=''
	set @columnMonths1=''
	set @tabWhereMonths=''
	--SET NOCOUNT ON;
	if @months<>0
	begin
	set @sqlMonths=' and months='+CONVERT(varchar(50),@months)
	set @sqlMonths1=' and r.months='+CONVERT(varchar(50),@months)
	set @columnMonths=' months,'
	set @columnMonths1=' r.months,'
	set @tabWhereMonths=' and table_situation.months=a.months '
	end
		
		
		set @sql='insert into table_situation(typecode, distid, distname,  tablename,shortDis, years,months,c1,c4,c2,c3,c5,c6)
		 select f.typecode, f.distid,f.distname,f.tableName,f.shortDis,f.years,'+convert(varchar(50),@months)+' as months,
						isnull(( select  COUNT(*)as c0 
							 from distEx
							  where years='+convert(varchar(50),@years)+'  and distId like '''+@distno+'%'' and tableName=f.tableName and distId =f.distId
							 group by years,distId,tablename
							),0 ) c1,(select COUNT(*) from dist where years='+CONVERT(varchar(50),@years)+' and distId like ''''+f.distId+''%'') as c4
							,0 as c2,0 as c3,0 as c5,0 as c6
	 			 from 
	 				(select distinct  years,distid,distname,tableName,shortDis,typeCode from filelist bb,
	 						(select dd.distId,dd.distname from dist dd,(select distid from dist t,'+@zcjydb+'.dbo.usermanager u where u.id='+convert(varchar(50),@userid)+' 
	 						and years='+CONVERT(varchar(50),@years)+' and t.distid=u.distno)uu where years='+convert(varchar(50),@years)+' and dd.distId like +uu.distid+''%'')d
						where typeCode='''+@tabletype+''' and years='+CONVERT(varchar(50),@years)+' and d.distid like '''+@distno+'%''  and tableType=''基本表'' and useFlag=''是'')f
			where not exists
			 (select * from table_situation s where s.distId=f.distid and s.tableName=f.tableName and s.years=f.years and s.months='+CONVERT(varchar(50),@months)+' and s.typeCode=f.typeCode)
			 
	 order by f.distid'
	 
	 exec (@sql)
	--print (@sql)
	set @sql=''
	
	set @sql='update table_situation set c2=0, c3=0,c5=0, c6=0 
	from (select distinct tableName from filelist where years='+CONVERT(varchar(50),@years)+' and typeCode='''+@tabletype+''' and tableType=''基本表'')f
	 where table_situation.years='+CONVERT(varchar(50),@years)+' and months='+CONVERT(varchar(50),@months)+' and distid like '''+@distno+'%'' and table_situation.tablename=f.tableName'
	exec (@sql)
	--print (@sql)
	declare tablelist cursor for select   tablename from filelist where years=@years and typeCode=''+@tabletype+'' and tableType='基本表' and useflag='是' order by orderid
	open tablelist
	fetch next from tablelist into @tablename
	
	while @@FETCH_STATUS=0
	begin
		
		set @existsLx=0	
	if exists(select * from fileItemLink where tableName=@tablename and years=@years )
	begin
		set @existsLx=1
		
		set @sql=' update table_situation set c2 =a.c0
						from (select r.years,'+@columnMonths+'r.distid,r.distname,COUNT(*) c0 from '+@tablename+' r,
							 (select distinct distId,distName,years, lxname  from distex where years='+CONVERT(varchar(50),@years)+' and tableName='''+@tablename+''')d
	 						where r.years='+CONVERT(varchar(50),@years)+@sqlMonths+' and r.distid like '''+@distno+'%'' and saveflag=''是''
							 and r.distid=d.distId and r.lxname=d.lxname
								 group by r.years,'+@columnMonths+'r.distid,r.distname)a
					 where table_situation.years=a.years '+@tabWhereMonths+'and table_situation.distid=a.distid and table_situation.tablename='''+@tablename+''''
		
		
		set @sql2='update table_situation set c5=a.c3 from 
						 (select r.years,'+@columnMonths1+'t.distid, COUNT(*) c3
									from (select distinct years,'+@columnMonths+'distid from  '+@tablename+' where years='+CONVERT(varchar(50),@years)+@sqlMonths+'  and distid like '''+@distno+'%'' and saveflag=''是'')
	   								  r,(select * from table_situation r where years='+CONVERT(varchar(50),@years)+@sqlMonths+' and distid like '''+@distno+'%'' and tablename='''+@tablename+''')t
										  where  r.years=t.years and     r.distid like ''''+t.distid+''%''
												group by r.years,'+@columnMonths1+'t.tablename,t.distid
	  							)a where table_situation.years=a.years '+@tabWhereMonths+' and  table_situation.distid=a.distid and  table_situation.tablename='''+@tablename+''''
		
	end
		else
		begin
		set @existsLx=0
		set @sql='update table_situation set c5=a.c3 from ( 
					select r.years,'+@columnMonths1+'t.distid, COUNT(*) c3
						from '+@tablename+' r,(select * from table_situation where years='+CONVERT(varchar(50),@years)+@sqlMonths+' and distid like '''+@distno+'%'' and tablename='''+@tablename+''')t
					where r.years='+CONVERT(varchar(50),@years)+@sqlMonths1+' and r.distid like '''+@distno+'%''
				 and saveflag=''是'' and r.distid like ''''+t.distid+''%''
				group by r.years,'+@columnMonths1+'t.tablename,t.distid)a
				where table_situation.years=a.years '+@tabWhereMonths+' and  table_situation.distid=a.distid and table_situation.tablename='''+@tablename+''''
				
	 	end
		if @sql!=''  exec (@sql)
		
		--print (@sql)
		if @sql2!='' exec (@sql2)
		--print (@sql2)
		set @sql=''
		set @sql2=''
		
		fetch next from tablelist into @tablename
	end 
close tablelist
deallocate tablelist
    
    set @sql='update table_situation set c3=a.c3,c6=a.c6
				from (
					select years,distid,distname,tablename,sum((c1-c2)) as c3,sum((c4-c5)) as c6     from table_situation
					where years='+CONVERT(varchar(50),@years)+' and distid like '''+@distno+'%'' and typecode='''+@tabletype+'''
					group by typecode,distid,distname,tablename,years,months)a
			where table_situation.typecode='''+@tabletype+''' and table_situation.years='+CONVERT(varchar(50),@years)+' and months='+CONVERT(varchar(50),@months)+' and table_situation.distid=a.distid and table_situation.tablename=a.tablename'
    exec (@sql)
  --  print (@sql)
END
go

