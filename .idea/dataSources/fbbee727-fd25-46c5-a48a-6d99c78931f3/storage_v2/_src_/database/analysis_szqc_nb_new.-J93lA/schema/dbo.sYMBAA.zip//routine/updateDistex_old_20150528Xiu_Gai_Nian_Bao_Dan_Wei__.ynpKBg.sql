 
create PROCEDURE [dbo].[updateDistex_old(20150528修改年报单位)] 
@opttype int,
@years int,
@typeCode varchar(50),
@tablename varchar(50),
@zcjydb varchar(50),
@bjaccount varchar(50),
@distno varchar(100)
AS
  
declare @sql varchar(6000)
declare @sqlup varchar(5000)
declare @sqllx varchar(5000)
declare @sqllxid varchar(5000)
BEGIN

	if @tablename=''
		declare basetable cursor for select t.tablename from filelist t,fileItemLink k 
		where  t.tablename=k.tablename and t.years=k.years and t.years=@years and typeCode=@typeCode and tableType='基本表'
		and not exists(select tableName from  Fileitemlinkexex ex where years=@years and ex.tableName=t.tableName and ex.distType= t.roleGrade)
		 order by orderid
	else
	declare basetable cursor for select t.tablename from filelist t,fileItemLink k
	 where t.tablename=k.tablename and t.years=k.years and t.tablename=@tablename and t.years=@years 
	 and typeCode=@typeCode and tableType='基本表'
	 and not exists(select tableName from  Fileitemlinkexex ex where years=@years and ex.tableName=t.tableName and ex.distType= t.roleGrade)
		  order by orderid
	open basetable
	fetch next from basetable into @tablename
		while @@FETCH_STATUS=0
	begin
	if @opttype=1
	begin
	--财务账套
	--set @sql='if exists(select * from distEx where tablename='''+@tablename+''')begin '
	set @sql='if exists(select * from '+@bjaccount+'.dbo.acc_set a where   scanflag=1  and acc_set not in(select acc_set from distex d where   tablename='''+@tablename+''' and years='+convert(varchar(50),@years)+' and distId like '''+@distno+'%''))
	begin
	insert into distEx( distId, distName, years, tableName, lx, lxname, lxid,  acc_modal, disid, acc_set)
	 select distid,distName,ff.years,ff.tablename,l.lx,acc_title,l.lxid,acc_modal,ff.disid,acc_set from (
	 select DISTINCT  d.distId,d.distname,'+convert(varchar(50),@years)+' as years,'''+@tablename
	 +''' as tablename,dwlx as lx,acc_title,L.lxid as lxid,a.acc_modal, 0 as disid,a.acc_set from '
	 +@bjaccount+'.dbo.acc_set a,dist d,middle_lxorder L where  scanflag=1  and d.years='+convert(varchar(50),@years)
	 +' and distId like '''+@distno+'%''and typeCode='''+@typeCode
	 +''' and a.dwlx=L.lx and a.linkDistId=d.distId )ff,
	 (select * from lxorder where years='+convert(varchar(50),@years)+' and typecode='''+@typeCode+''')l,(select * from fileItemLinkEx where years='+convert(varchar(50),@years)+' and tableName='''+@tablename+''')f
	  where 
	  ff.lxid=l.lxid and l.lx=f.prjItem  and  not exists (select acc_set from distex where years='+convert(varchar(50),@years)+' and distId like '''+@distno+'%'' and tableName='''+@tablename+''' and distex.acc_set=ff.acc_set)
	 	end'
   exec(@sql)
    -- print @sql
	end
	else if @opttype=2
	begin
	--资产账套
	set @sql='if exists (select * from '+@zcjydb+'.dbo.zt z where distno like '''+@distno+'%'' and not exists(select ztId from distEx d where z.ztid=d.ztid and tablename='''+@tablename+''' and years='+convert(varchar(50),@years)+' and distId like '''+@distno+'%''))
	begin
	insert into distEx(distId, distName, years, tableName, lx, lxname, lxid, ztId, ztName, acc_modal, disid, acc_set) 
	select  distno as distId, (select distname from dist where years='+convert(varchar(50),@years)+' and distId=z.distno) as distName,'+convert(varchar(50),@years)+' as  years, '''+@tablename+''' as tableName, ( select codename from '+@zcjydb+'.dbo.code where tname=''帐套类型'' and code=z.ztTypeId) as lx,ztjc as lxname, z.ztTypeId as lxid,ztId, ztName,0 as acc_modal,0 as disid,BS_ztNo as  acc_set 
     from '+@zcjydb+'.dbo.zt z,(select * from fileItemLinkEx where years='+convert(varchar(50),@years)+' and tablename='''+@tablename+''')f   where distno like '''+@distno+'%''
     and (select codename from '+@zcjydb+'.dbo.code   where tname=''帐套类型'' and code=z.ztTypeId) =f.prjItem 
      and not exists(select ztid from distEx where years='+convert(varchar(50),@years)+' and distId like '''+@distno+'%'' and tableName='''+@tablename+''' and distex.ztid=z.ztid)
 	end	'
     --exec(@sql)
      print @sql
	end
	
	/*--类型id
	set @sql='update distEx set lxid=l.lxid from distEx d,middle_lxorder L where d.lx=l.lx and d.years=l.years
			and d.years='+convert(varchar(50),@years)+' and l.typeCode='''+@typeCode+''' and distId like '''+@distno+'%'''
	exec(@sql)
	--print @sql
	
	--类型名
	set @sql='update distEx set distex.lx=lx.lx from (select lx,lxid from lxorder where years='+convert(varchar(50),@years)+' and typeCode='''+@typeCode+''') lx
	 	 where distEx.years='+convert(varchar(50),@years)+' and tableName='''+@tablename+''' and distEx.lxid=lx.lxid'
	 	
	 	exec(@sql)		*/
    fetch next from basetable into @tablename
	end
	close basetable
	 deallocate basetable
	 
	 
	 --
	 --set @tablename=''
	--if @tablename=''
	declare @roleGrade varchar(100)
	declare xulx cursor for select t.tablename,t.roleGrade from filelist t,fileItemLink k 
		where t.tablename=k.tablename and t.years=k.years  and t.years=@years 
	and   exists(select tableName from  Fileitemlinkexex ex where years=@years 
	and ex.tableName=t.tableName and ex.distType= t.roleGrade)
	and typeCode=@typeCode and tableType='基本表' order by orderid
	/*else
	declare xulx cursor for select t.tablename from filelist t,fileItemLink k
	 where t.tablename=k.tablename and t.years=k.years and t.tablename=@tablename and t.years=@years 
	 and typeCode=@typeCode and tableType='基本表'
	 and not exists(select tableName from  Fileitemlinkexex ex where years=@years and ex.tableName=t.tableName and ex.distType= t.roleGrade)
		  order by orderid*/
	open xulx
	fetch next from xulx into @tablename,@roleGrade
		while @@FETCH_STATUS=0
		begin
		set @sql='insert into distEx(distId, distName, years, tableName, lx, lxname, lxid) 
		select distId, distName, d.years, tableName, f.prjItem as lx,(d.distName+f.prjItem) as lxname,
		 (select lxid from middle_lxorder where years='+convert(varchar(50),@years)+'  and typecode='''+@typeCode+''' and lx=f.prjItem) as  lxid 
		  from dist  d,(select tableName,prjItem,distType from  Fileitemlinkexex
	   where years='+convert(varchar(50),@years)+' and tableName='''+@tablename+'''  and distType='''+@roleGrade+''')f
	   where years='+convert(varchar(50),@years)+' and distId like '''+@distno+'%'' and d.distType=f.distType
	   and not exists(select * from distEx where years=d.years and distId=d.distId and tableName=f.tableName 
	   and lxid=(select lxid from middle_lxorder where years='+convert(varchar(50),@years)
	   +'  and typecode='''+@typeCode+''' and lx=f.prjItem) 
	   and lx=f.prjItem and lxname=(d.distName+f.prjItem) 
		)'
	 --exec (@sql)
	 print (@sql)
	fetch next from xulx into @tablename,@roleGrade
	end
	close xulx
	 deallocate xulx
	 
	 --类型id
	set @sql='update distEx set lxid=l.lxid from distEx d,middle_lxorder L where d.lx=l.lx and d.years=l.years
			and d.years='+convert(varchar(50),@years)+' and l.typeCode='''+@typeCode+''' and distId like '''+@distno+'%'''
	exec(@sql)
	--print @sql
	
	--类型名
	set @sql='update distEx set distex.lx=lx.lx from (select lx,lxid from lxorder where years='+convert(varchar(50),@years)+' and typeCode='''+@typeCode+''') lx
	 	 where distEx.years='+convert(varchar(50),@years)+'  and distEx.lxid=lx.lxid'
	 	
	 	exec(@sql)	
END
go

