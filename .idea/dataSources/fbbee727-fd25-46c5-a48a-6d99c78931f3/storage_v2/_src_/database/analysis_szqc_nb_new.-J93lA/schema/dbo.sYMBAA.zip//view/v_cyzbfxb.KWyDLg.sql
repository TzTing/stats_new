CREATE VIEW dbo.v_cyzbfxb
AS
SELECT dbo.rep902.years, dbo.rep902.distid, dbo.rep902.distname, 
      dbo.rep901.c12 AS 总人口, dbo.rep902.c1 AS 总收入, 
      dbo.rep902.c1 / dbo.rep901.c12 AS 人均总收入, 
      dbo.rep902.c9 + dbo.rep902.c13 + dbo.rep902.c15 + dbo.rep902.c17 AS [第一产业|收入],
       (dbo.rep902.c9 + dbo.rep902.c13 + dbo.rep902.c15 + dbo.rep902.c17) 
      * 100 / dbo.rep902.c1 AS [第一产业|占总收入], 
      dbo.rep902.c19 + dbo.rep902.c20 + dbo.rep902.c21 AS [第二产业|收入], 
      (dbo.rep902.c19 + dbo.rep902.c20 + dbo.rep902.c21) 
      * 100 / dbo.rep902.c1 AS [第二产业|占总收入], 
      dbo.rep902.c22 + dbo.rep902.c23 + dbo.rep902.c24 AS [第三产业|收入], 
      (dbo.rep902.c22 + dbo.rep902.c23 + dbo.rep902.c24) 
      * 100 / dbo.rep902.c1 AS [第三产业|占总收入], dbo.rep902.c42 AS 人均所得, 
      dbo.rep905.c2 AS 集体经营收入, dbo.rep906.c28 AS 集体净资产, 
      dbo.rep901.years AS Expr1, dbo.rep901.distid AS Expr2, 
      dbo.rep901.distname AS Expr3, dbo.rep905.distname AS Expr4, 
      dbo.rep905.distid AS Expr5, dbo.rep905.years AS Expr6, 
      dbo.rep906.distname AS Expr7, dbo.rep906.distid AS Expr8, 
      dbo.rep906.years AS Expr9
FROM dbo.rep906 INNER JOIN
      dbo.rep905 ON dbo.rep906.lx = dbo.rep905.lx AND 
      dbo.rep906.distid = dbo.rep905.distid AND 
      dbo.rep906.years = dbo.rep905.years INNER JOIN
      dbo.rep901 INNER JOIN
      dbo.rep902 ON dbo.rep901.distname = dbo.rep902.distname AND 
      dbo.rep901.distid = dbo.rep902.distid AND dbo.rep901.years = dbo.rep902.years ON 
      dbo.rep905.lx = '汇总数' AND dbo.rep905.distid = dbo.rep902.distid AND 
      dbo.rep905.distname = dbo.rep901.distname AND 
      dbo.rep905.distid = dbo.rep901.distid AND 
      dbo.rep905.years = dbo.rep901.years
WHERE (dbo.rep902.lx = '汇总数') AND (dbo.rep902.c1 <> 0) AND 
      (dbo.rep901.c12 <> 0) OR
      (dbo.rep902.lx IS NULL)
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[31] 4[29] 2[18] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1[50] 2[25] 3) )"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1 [56] 4 [18] 2))"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "rep906"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 109
               Right = 172
            End
            DisplayFlags = 280
            TopColumn = 2
         End
         Begin Table = "rep905"
            Begin Extent = 
               Top = 6
               Left = 210
               Bottom = 109
               Right = 344
            End
            DisplayFlags = 280
            TopColumn = 1
         End
         Begin Table = "rep901"
            Begin Extent = 
               Top = 6
               Left = 382
               Bottom = 109
               Right = 516
            End
            DisplayFlags = 280
            TopColumn = 1
         End
         Begin Table = "rep902"
            Begin Extent = 
               Top = 6
               Left = 554
               Bottom = 109
               Right = 688
            End
            DisplayFlags = 280
            TopColumn = 1
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      RowHeights = 240
      Begin ColumnWidths = 25
         Width = 284
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
      E', 'SCHEMA', 'dbo', 'VIEW', 'v_cyzbfxb'
go

exec sp_addextendedproperty 'MS_DiagramPane2', N'nd
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 8610
         Alias = 3390
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'v_cyzbfxb'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 2, 'SCHEMA', 'dbo', 'VIEW', 'v_cyzbfxb'
go

