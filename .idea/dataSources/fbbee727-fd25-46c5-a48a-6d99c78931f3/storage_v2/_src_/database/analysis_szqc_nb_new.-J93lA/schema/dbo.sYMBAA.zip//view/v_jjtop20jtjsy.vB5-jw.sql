CREATE VIEW dbo.v_jjtop20jtjsy
AS
SELECT TOP 20 rep902.years,
          (SELECT distname
         FROM dist
         WHERE years = rep902.years AND distid = LEFT(rep902.distid, len(rep902.distid) 
               - 3)) AS Expr1, distname, c37, c31
FROM dbo.rep902
WHERE (lx = '经济社') AND (LEN(distid) IN
          (SELECT TOP 1 len(distid)
         FROM dist
         WHERE years = rep902.years AND disttype = '村')) and years=rep902.years
ORDER BY c37 DESC


go

