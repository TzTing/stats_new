CREATE VIEW dbo.v_rjsr1
AS
SELECT TOP 100 PERCENT
          (SELECT distname
         FROM dist
         WHERE years = ccc.years AND len(distid) = 6 - 3) AS distname, *
FROM (SELECT 1 AS lxid, *,
                  (SELECT distname
                 FROM dist
                 WHERE years = aaa.years AND distid = aaa.distno) +
                  (SELECT TOP 1 distname
                 FROM rep902
                 WHERE years = aaa.years AND lx = aaa.jls AND 
                       distid LIKE aaa.distno + '%' AND distid <> aaa.distno AND 
                       c42 = aaa.jlsrps) AS jlsname, '' AS jjs, 0 AS jjsrps, 
              '' AS jjsname
        FROM (SELECT years, LEFT(distid, 6) AS distno, lx AS jls, MIN(c42) AS jlsrps
                FROM rep902
                WHERE len(distid) <> 6
                GROUP BY years, lx, LEFT(distid, 6)) aaa
        UNION
        SELECT 2 AS lxid, years, distno, '' AS jls, 0 AS jlsrps, '' AS jlsname, jjs, jjsrps,
                  (SELECT distname
                 FROM dist
                 WHERE years = bbb.years AND distid = bbb.distno) +
                  (SELECT TOP 1 distname
                 FROM rep902
                 WHERE years = bbb.years AND lx = bbb.jjs AND 
                       distid LIKE bbb.distno + '%' AND distid <> bbb.distno AND 
                       c42 = bbb.jjsrps) AS jjsname
        FROM (SELECT years, LEFT(distid, 6) AS distno, lx AS jjs, MIN(c42) AS jjsrps
                FROM rep902
                WHERE len(distid) <> 6
                GROUP BY years, lx, LEFT(distid, 6)) bbb) ccc
WHERE (jls = '经联社') AND (jjs = '') OR
      (jls = '') AND (jjs = '经济社')
ORDER BY lxid


go

